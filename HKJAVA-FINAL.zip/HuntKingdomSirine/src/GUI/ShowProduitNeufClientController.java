/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;


import Models.ProduitNeuf;
import Models.ProduitNeufListCell;
import Models.User;
import Services.CommandeService;
import Services.ProduitNeufService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author kaisk
 */
public class ShowProduitNeufClientController implements Initializable {
    
    protected static User user;
    @FXML
    private ListView<ProduitNeuf> ListProduct;
    @FXML
    private Button afficherButton;
    @FXML
    private Button returnButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // TODO
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowProduitNeufClientController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShowProduitNeufClientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    private void Load() throws SQLException, IOException {
        for(int i=0; i<ListProduct.getItems().size(); i++) {
            ListProduct.getItems().clear();
        }
        
        ProduitNeufService pns = new ProduitNeufService();
        ObservableList<ProduitNeuf> plist = pns.afficherListeProduitNeufNonNul();       
        ListProduct.setItems(plist);
        ListProduct.setCellFactory(new Callback<ListView<ProduitNeuf>, ListCell<ProduitNeuf>>() { 
            @Override 
            public ListCell<ProduitNeuf> call(ListView<ProduitNeuf> lv) { 
                return new ProduitNeufListCell();
            }
        });
        
    }

    @FXML
    private void afficherProduit(ActionEvent event) throws IOException {
        if(ListProduct.getSelectionModel().getSelectedItem() != null){
            ProduitNeuf p = ListProduct.getSelectionModel().getSelectedItem();
            ShowOneProductController.maxValueSpinner = p.getNbProduits();
            ShowOneProductController.price= p.getPrix();
            ShowOneProductController.idPro= p.getIdProdNeuf();
            ShowOneProductController.user= user;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowOneProduct.fxml"));
            Parent root = loader.load();
            ListProduct.getScene().setRoot(root);
            ShowOneProductController etc = loader.getController();
            etc.nomText.setText(p.getNom());
            etc.descText.setText(p.getDescription());
            etc.ctgText.setText(p.getCategorie());
            etc.prixText.setText(Float.toString(p.getPrix()));
            etc.qteText.setText(Integer.toString(p.getNbProduits()));
            String path = "/Resources/produitNeuf/0.png";
            File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/produitNeuf/"+p.getIdProdNeuf()+".jpg");
            if(tmp.exists()){
                path = "/Resources/produitNeuf/"+p.getIdProdNeuf()+".jpg";
            }
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
                etc.imageViewer.setImage(image);
            }
        }
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        ListProduct.getScene().setRoot(root);
    }
    
}
