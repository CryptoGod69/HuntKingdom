/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.ShowPostController.topicId;
import Models.Post;
import Models.PostListCell;
import Models.User;
import Services.PostService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class ShowPostFrontController implements Initializable {

    @FXML
    private ListView<Post> postList;
    @FXML
    private Button returnButton;
    @FXML
    private Button addButton;

    protected static int topicId;
    protected static User user;
    
    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.YELLOW)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("50% PROMO ON ALL AMMO")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.MIRROR)
                                 .postEffect(Content.PostEffect.STOP)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopicFront.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        postList.getScene().setRoot(root);
    }

    @FXML
    private void Add(ActionEvent event) throws IOException {
        PostService ps = new PostService();
        if(ps.topicState(topicId).equals("open")){
            AddPostFrontController.topicId = topicId;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddPostFront.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            postList.getScene().setRoot(root);
            AddPostFrontController apc = loader.getController();
            apc.authorField.setText(user.getUsername());
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Solved");
            alert.setContentText("Sorry this topic is solved");
            alert.showAndWait();
        }
    }
    
    private void Load() {
        for(int i=0; i<postList.getItems().size(); i++) {
            postList.getItems().clear();
        }
        PostService ps = new PostService();
        ObservableList<Post> plist = ps.readPostTopic(topicId);
        postList.setItems(plist);
        postList.setCellFactory(new Callback<ListView<Post>, ListCell<Post>>() { 
            @Override 
            public ListCell<Post> call(ListView<Post> lv) { 
                return new PostListCell();
            }
        });
    }
    
}
