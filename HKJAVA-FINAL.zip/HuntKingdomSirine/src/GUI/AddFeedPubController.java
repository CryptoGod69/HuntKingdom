/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Feed;
import Models.User;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class AddFeedPubController implements Initializable {
    protected static User user;
    @FXML
    private TextField titreField;
    @FXML
    private TextField contField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void cancel(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
    }

    @FXML
    private void save(ActionEvent event) throws IOException, SQLException {
            FeedService fs = new FeedService();
            Feed f = new Feed(user.getUsername(),titreField.getText() ,contField.getText());
            fs.addPub(f);
            System.out.println("OK");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPub.fxml"));
            Parent root = loader.load();
            titreField.getScene().setRoot(root);
            ShowFeedPubController spc = loader.getController();
            SuccesNotification();
        }
      @FXML
    private void SuccesNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Success :)")
                .text("Operation Succeeded")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
                      
        notificationBuilder.showConfirm();  
    }
    @FXML
    private void ErrorNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Fail :(")
                .text("Operation Failed")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
        notificationBuilder.showError();       
    }
    }
    

