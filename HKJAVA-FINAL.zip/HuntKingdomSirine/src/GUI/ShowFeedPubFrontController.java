/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Models.EvenementListCell;
import Models.Feed;
import Models.FeedListCell;
import Models.User;
import Services.EvenementService;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowFeedPubFrontController implements Initializable {
    protected static User user;
    private ListView<Feed> EventList;
    @FXML
    private Button addButton;
    @FXML
    private Button eventButton;
    @FXML
    private ListView<Feed> FeedList;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowFeedPubFrontController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    @FXML
    private void Add(ActionEvent event) throws IOException {
        AddFeedPubFrontController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddFeedPubFront.fxml"));
        Parent root = loader.load();
        FeedList.getScene().setRoot(root);
    }

    private void Load() throws SQLException {
        for(int i=0; i<FeedList.getItems().size(); i++){
            FeedList.getItems().clear();
        }
        FeedService fs = new FeedService();
        ObservableList<Feed> flist = fs.showPubList();
        FeedList.setItems(flist);
          
        FeedList.setCellFactory(new Callback<ListView<Feed>, ListCell<Feed>>() { 
            @Override 
            public ListCell<Feed> call(ListView<Feed> lv) { 
                return new FeedListCell(); 
            } 
        });      
    }

    @FXML
    private void goEvent(ActionEvent event) throws IOException {
        ShowEventsFrontController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEventsFront.fxml"));
        Parent root = loader.load();
        FeedList.getScene().setRoot(root);
    }
    
}
