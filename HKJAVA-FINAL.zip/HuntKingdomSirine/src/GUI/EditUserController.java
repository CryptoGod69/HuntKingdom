/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Services.UserService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author user
 */
public class EditUserController implements Initializable {

    @FXML
    protected TextField usernameChange;
    @FXML
    protected TextField emailChange;
    @FXML
    private Button cancelButton;
    
    protected static int id;
    @FXML
    protected ComboBox<String> roleCombo;
    
    ObservableList<String> roleList = FXCollections.observableArrayList("admin","user");
    @FXML
    private Button saveButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        roleCombo.setItems(roleList);
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowUser.fxml"));
        Parent root = loader.load();
        usernameChange.getScene().setRoot(root);
        ShowUserController spc = loader.getController();
    }

    @FXML
    private void Save(ActionEvent event) throws IOException {
        UserService us = new UserService();
        String role;
        if(roleCombo.getValue()=="admin"){
            role = "a:1:{i:0;s:10:"+"ROLE_ADMIN"+";}";
        }else if(roleCombo.getValue()=="user"){
            role = "N;";
        }
        us.updateUser(id,usernameChange.getText(),emailChange.getText(),roleCombo.getValue());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowUser.fxml"));
        Parent root = loader.load();
        usernameChange.getScene().setRoot(root);
    }
}
