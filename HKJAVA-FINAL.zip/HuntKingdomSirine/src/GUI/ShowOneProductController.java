/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Commande;
import Models.ProduitNeuf;
import Models.User;
import Services.ProduitNeufService;
import Services.CommandeService;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author kaisk
 */
public class ShowOneProductController implements Initializable {
    protected static User user;
    protected static int idPro;
    protected static float price;
    protected static int maxValueSpinner;
    @FXML
    protected Label nomText;
    @FXML
    protected Label ctgText;
    @FXML
    protected Label descText;
    @FXML
    protected Label prixText;
    @FXML
    protected Label qteText;
    @FXML
    protected ImageView imageViewer;
    @FXML
    private Spinner<Integer> spinnerValue;
    @FXML
    private Button acheterButton;
    @FXML
    private Button cancelButton;
    @FXML
    private TextField adField;
    @FXML
    private TextField phField;
    
    /**
     * Initializes the controller class.
     */
       
        
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, maxValueSpinner, 0);
        spinnerValue.setValueFactory(valueFactory);
    }    
   

    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeufClient.fxml"));
        Parent root = loader.load();
        qteText.getScene().setRoot(root);
    }

    public float calculerTotal(int qte, float prix) throws SQLException{
        return qte * prix;
    }
    
    @FXML
    private void buyProduct(ActionEvent event) throws SQLException, IOException {
            float totalF =  calculerTotal(spinnerValue.getValue(),price);
            String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            CommandeService pn = new CommandeService();           
            Commande c = new Commande(0,user.getId(),idPro,date,totalF,0,spinnerValue.getValue(),adField.getText(),Integer.parseInt(phField.getText()));
            pn.ajouterCommande(c);
            ProduitNeufService pns = new ProduitNeufService();
            pns.decrementProduitNeuf(idPro,spinnerValue.getValue());
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeufClient.fxml"));
            Parent root = loader.load();
            nomText.getScene().setRoot(root);
    }

    
       
    
}
