/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.HomeController.user;
import Models.Article;
import Models.ArticleListCell;
import Models.User;
import Services.ArticleService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class ShowArticleUserController implements Initializable {

    @FXML
    private ListView<Article> articleList;
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Button periodeChasseButton;
    @FXML
    private Button readButton;
    @FXML
    private Button cancelButton;
    protected static User user;
    @FXML
    private Button returnButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    
    private void Load() {
        for(int i=0; i<articleList.getItems().size(); i++){
            articleList.getItems().clear();
        }
        ArticleService as = new ArticleService();
        ObservableList<Article> alist =as.getListArticle();
        articleList.setItems(alist);
        articleList.setCellFactory(new Callback<ListView<Article>, ListCell<Article>>() { 
            @Override 
            public ListCell<Article> call(ListView<Article> lv) { 
                return new ArticleListCell(); 
            } 
        });
     }
    @FXML
    private void Search(ActionEvent event) {
          for(int i=0; i<articleList.getItems().size(); i++){
            articleList.getItems().clear();
        }
        ArticleService as = new ArticleService();
        ObservableList<Article> alist =as.rechercherArticleCategorie(searchField.getText());
        articleList.setItems(alist);
        articleList.setCellFactory(new Callback<ListView<Article>, ListCell<Article>>() { 
            @Override 
            public ListCell<Article> call(ListView<Article> lv) { 
                return new ArticleListCell(); 
            } 
        });
    }

    @FXML
    private void GoPeriodeChasse(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasseUser.fxml"));
        Parent root = loader.load();
        articleList.getScene().setRoot(root);
    }

    @FXML
    private void Read(ActionEvent event) throws IOException {
        ReadArticleUserController.user = user;
        if(articleList.getSelectionModel().getSelectedItem() != null){
            Article a = articleList.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ReadArticleUser.fxml"));
            Parent root = loader.load();
            articleList.getScene().setRoot(root);
            ReadArticleUserController rac = loader.getController();
            rac.categorieLabel.setText(a.getCategorie());
            rac.titreLabel.setText(a.getTitre());
            rac.sousTitreLabel.setText(a.getSousTitre());
            rac.chapeauLabel.setText(a.getChapeau());
            rac.texteLabel.setText(a.getTexte());
            ReadArticleUserController.idTest=a.getIdA();
            String path = "";
            path = "/Resources/articles/"+a.getIdA()+".jpg";
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
                rac.articleView.setImage(image);
            }
            }
        }

    @FXML
    private void Cancel(ActionEvent event) {
        Load();
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        returnButton.getScene().setRoot(root);
    }
    }
    
