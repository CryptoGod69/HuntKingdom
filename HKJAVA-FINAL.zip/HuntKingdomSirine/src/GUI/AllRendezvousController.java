/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.RdvListCell;
import Models.Rendezvous;
import Services.RendezvousService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Rym
 */
public class AllRendezvousController implements Initializable {

    @FXML
    private ListView<Rendezvous> listeRDV;
    @FXML
    private Button cancelButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    
private void Load() {
        RendezvousService rdv = new RendezvousService();
        ObservableList<Rendezvous> list = rdv.getListRendezvous();
        listeRDV.setItems(list);
         listeRDV.setItems(list);
        listeRDV.setCellFactory(new Callback<ListView<Rendezvous>, ListCell<Rendezvous>>() { 
            @Override 
            public ListCell<Rendezvous> call(ListView<Rendezvous> lv) { 
                return new RdvListCell();
            }
        });
    }
    

    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        cancelButton.getScene().setRoot(root);
    }
    
}
