/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Topic;
import Models.TopicListCell;
import Models.User;
import Services.TopicService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class ShowTopicController implements Initializable {
    
    @FXML
    private ListView<Topic> topicList;
    @FXML
    private Button addButton;
    @FXML
    private Button switchStateButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button editButton;
    @FXML
    private Button showButton;

    protected static User user;
    
    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("DONT ASK STUPID QUESTIONS")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SCROLL_LEFT)
                                 .effect(Content.Effect.BLINK)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    @FXML
    private Button returnButton;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    

    @FXML
    private void Add(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddTopic.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        topicList.getScene().setRoot(root);
        AddTopicController atc = loader.getController();
        atc.authorField.setText(user.getUsername());
    }

    private void Load() {
        for(int i=0; i<topicList.getItems().size(); i++) {
            topicList.getItems().clear();
        }
        TopicService ts = new TopicService();
        ObservableList<Topic> tlist = ts.readTopicList();
        topicList.setItems(tlist);
        topicList.setCellFactory(new Callback<ListView<Topic>, ListCell<Topic>>() { 
            @Override 
            public ListCell<Topic> call(ListView<Topic> lv) { 
                return new TopicListCell(); 
            } 
        });
    }

    @FXML
    private void Delete(ActionEvent event) {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            TopicService ts = new TopicService();
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ts.deleteTopic(t.getId());
            Load();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("The topic was deleted successfully");
            alert.showAndWait();
        }
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            Topic t = topicList.getSelectionModel().getSelectedItem();
            EditTopicController.id = t.getId();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditTopic.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            topicList.getScene().setRoot(root);
            EditTopicController etc = loader.getController();
            etc.titleField.setText(t.getTitle());
            etc.authorField.setText(t.getAuthor());
        }
    }

    @FXML
    private void Show(ActionEvent event) throws IOException {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ShowPostController.user = user;
            ShowPostController.topicId = t.getId();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            topicList.getScene().setRoot(root);
            ShowPostController spc = loader.getController();
        }
    }

    @FXML
    private void SwitchState(ActionEvent event) {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            TopicService ts = new TopicService();
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ts.switchState(t.getId());
            Load();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("State switched successfully");
            alert.showAndWait();
        }
        
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        topicList.getScene().setRoot(root);
    }
    
}
