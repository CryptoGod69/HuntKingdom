/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.User;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author user
 */
public class HomeController implements Initializable {

    public static User user;
    @FXML
    private Button myProfileButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Label welcomeLabel;
    @FXML
    private Button forumButton;
    @FXML
    private Button blogButton;
    @FXML
    private Button shopNeufButton;
    @FXML
    private Button shopOccasionButton;
    @FXML
    private Button feedEventButton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        welcomeLabel.setText("Welcome "+user.getUsername()+" !");
    }

    @FXML
    private void Logout(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void Forum(ActionEvent event) throws IOException {
            MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("DONT ASK STUPID QUESTIONS")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SCROLL_LEFT)
                                 .effect(Content.Effect.BLINK)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
        ShowTopicFrontController.user = user;
        FXMLLoader loader = new FXMLLoader();
        loader = new FXMLLoader(getClass().getResource("ShowTopicFront.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void Blog(ActionEvent event) throws IOException {
        ShowArticleUserController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticleUser.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void ShopNeuf(ActionEvent event) throws IOException {
        ShowProduitNeufClientController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeufClient.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void ShopOccasion(ActionEvent event) throws IOException {
        ShowProduitController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduit.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void FeedEvent(ActionEvent event) throws IOException {
        ShowEventsFrontController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEventsFront.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void MyProfile(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ProfilUser.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
        ProfilUserController.user = user;
        ProfilUserController puc = loader.getController();
        puc.image.setImage(null);
        puc.emailLabel.setText(user.getEmail());
        puc.usernameLabel.setText(user.getUsername());
        String path = "/Resources/users/0.png";
        File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/users/"+user.getId()+".jpg");
        if(tmp.exists()){
        path = "/Resources/users/"+user.getId()+".jpg";
        }
        Image image = new Image(getClass().getResource(path).toExternalForm());
        puc.image.setImage(image);
    }
    
}
