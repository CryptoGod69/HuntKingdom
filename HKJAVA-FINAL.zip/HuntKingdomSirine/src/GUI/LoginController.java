/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.User;
import Services.UserService;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import Utils.DataSource;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import org.mindrot.jbcrypt.BCrypt;

/**
 * FXML Controller class
 *
 * @author user
 */
public class LoginController implements Initializable {

    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private Button btnSignin;
    @FXML
    private Label btnForgot;
    @FXML
    private Button btnFB;
    @FXML
    private Button btnSignup;
    @FXML
    private Label lblErrors;
    
    

    /**
     * Initializes the controller class.
     */
    
     Connection cnx =null; 
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    @FXML
    public void handleButtonAction(MouseEvent event) throws SQLException {

        if (event.getSource() == btnSignin) {
            User u = logIn();
            if (u != null) {
                try {
                    UserService us = new UserService();
                    //add you loading or delays - ;-)
                    Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow();
                   
                    Scene scene;
                    if(!u.getEnabled()){
                        if(u.getRoles().equals("N;")){
                            stage.close();
                            HomeController.user = u;
                            scene = new Scene(FXMLLoader.load(getClass().getResource("/GUI/Home.fxml")));
                            stage.setScene(scene);
                            stage.getScene().getStylesheets().add(getClass().getResource("/GUI/Main.css").toExternalForm());
                            stage.show();
                        
                        }else if(u.getRoles().equals("a:1:{i:0;s:10:\"ROLE_ADMIN\";}")){
                            stage.close();
                            HomeAdminController.user = u;
                            scene = new Scene(FXMLLoader.load(getClass().getResource("/GUI/HomeAdmin.fxml")));
                            stage.setScene(scene);
                            stage.getScene().getStylesheets().add(getClass().getResource("/GUI/Main.css").toExternalForm());
                            stage.show();
                        }
                    }else{
                        lblErrors.setTextFill(Color.TOMATO);
                        lblErrors.setText("Sorry, your account is banned !");
                    }
                    

                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }

            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        if (cnx == null) {
            lblErrors.setTextFill(Color.TOMATO);
            lblErrors.setText("Server Error : Check");
        } else {
            lblErrors.setTextFill(Color.GREEN);
            lblErrors.setText("Server is up : Good to go");
        }
    }

    public LoginController() {
         cnx = DataSource.getInstance().getCnx(); 
    }

    //we gonna use string to check for status
    private User logIn() {
        User u = null;
        String status = "Success";
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        if(username.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            status = "Error";
        } else {
            //query
            //String sql = "SELECT * FROM fos_user_table Where email = ? and password = ?";
            //try{
                UserService US = new UserService();
                boolean test=false;
                ObservableList<User> T = US.showUsersList();
                for (int i=0 ; i<T.size() ; i++){
                    if (checkPassword(password, T.get(i).getPassword())&&username.equals(T.get(i).getUsername())){
                        test=true;
                        u = T.get(i);
                    }
                }
                if (!test) {
                    setLblError(Color.TOMATO, "Enter Correct Email/Password");
                    status = "Error";
                } else {
                    setLblError(Color.GREEN, "Login Successful..Redirecting..");
                }
            /*} catch (SQLException ex) {
                System.err.println(ex.getMessage());
                status = "Exception";
            }*/
        }
        System.out.println(status);
        return u;
    }
    
    public boolean checkPassword(String passwordText, String DbHash) {
        boolean password_verified = false;
        String PwdH = DbHash.substring(4, 60);
        PwdH = "$2a$"+PwdH ;
        if (null == DbHash) {
            throw new java.lang.IllegalArgumentException("Invalid hash provided for comparison");
        }
        password_verified = BCrypt.checkpw(passwordText, PwdH);
        return (password_verified);
    }
    
    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
    }

    @FXML
    private void SignUp(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddUser.fxml"));
        Parent root = loader.load();
        txtUsername.getScene().setRoot(root);
    }
}

  
    

