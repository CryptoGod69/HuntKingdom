/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.User;
import Services.UserService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ShowUserController implements Initializable {

    @FXML
    private TableView<User> userList;
    @FXML
    private TableColumn<User, String> usernameColumn;
    @FXML
    private TableColumn<User, String> roleColumn;
    @FXML
    private TableColumn<User, String> emailColumn;
    @FXML
    private Button editButton;
    @FXML
    private Button returnButton;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }   
    
    private void Load(){
        UserService us = new UserService();
        ObservableList<User> ulist = us.showUsersList();
        for(int i=0; i<ulist.size(); i++){
            System.out.println(ulist.get(i).getRoles());
            if (ulist.get(i).getRoles().contains("ROLE_ADMIN")){
                ulist.get(i).setRoles("admin");
            }else{
                ulist.get(i).setRoles("user");
            }
        }
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("roles"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        userList.setItems(ulist);
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
        if(userList.getSelectionModel().getSelectedItem() != null){
        User u = userList.getSelectionModel().getSelectedItem();
        EditUserController.id = u.getId();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditUser.fxml"));
        Parent root = loader.load();
        userList.getScene().setRoot(root);
        EditUserController euc = loader.getController();
        euc.emailChange.setText(u.getEmail());
        euc.usernameChange.setText(u.getUsername());
        String role;
        if(u.getRoles() == "N;"){
            role = "user";
        }else{
            role = "admin";
        }
        euc.roleCombo.setValue(role);
        }
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        userList.getScene().setRoot(root);
    }
    
}
