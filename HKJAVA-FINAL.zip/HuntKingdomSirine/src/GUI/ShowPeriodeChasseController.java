/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;


import Models.Article;
import Models.ArticleListCell;
import Models.PeriodeChasse;
import Models.PeriodeChasseListCell;
import Services.ArticleService;
import Services.PeriodeChasseService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Legion
 */
   public class ShowPeriodeChasseController implements Initializable {

    @FXML
    private ListView<PeriodeChasse> PeriodeChasseList;
    @FXML
    private Button searchButton;
    @FXML
    private Button addButton;
    @FXML
    private Button articleButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private TextField searchField;
    @FXML
    private Button cancelButton;
    
    ObservableList<PeriodeChasse> pplist;
    private PeriodeChasse periodeTest;
    @FXML
    private Button returnButton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    
    
    private void Load() {
        for(int i=0; i<PeriodeChasseList.getItems().size(); i++){
            PeriodeChasseList.getItems().clear();
        }
        PeriodeChasseService pcs = new PeriodeChasseService();
        ObservableList<PeriodeChasse> plist =pcs.getListPeriodeChasse();
        PeriodeChasseList.setItems(plist);
        PeriodeChasseList.setCellFactory(new Callback<ListView<PeriodeChasse>, ListCell<PeriodeChasse>>() { 
            @Override 
            public ListCell<PeriodeChasse> call(ListView<PeriodeChasse> lv) { 
                return new PeriodeChasseListCell(); 
            } 
        });
        pplist=plist;
       if (plist.size()>0){
           periodeTest=plist.get(plist.size()-1);
       }
     }
    @FXML
    private void Search(ActionEvent event) {
        for(int i=0; i<PeriodeChasseList.getItems().size(); i++){
            PeriodeChasseList.getItems().clear();
        }
        PeriodeChasseService pcs = new PeriodeChasseService();
        ObservableList<PeriodeChasse> plist =pcs.rechercherPeriodeChasseAdresse(searchField.getText());
        PeriodeChasseList.setItems(plist);
        PeriodeChasseList.setCellFactory(new Callback<ListView<PeriodeChasse>, ListCell<PeriodeChasse>>() { 
            @Override 
            public ListCell<PeriodeChasse> call(ListView<PeriodeChasse> lv) { 
                return new PeriodeChasseListCell(); 
            } 
        });
        
    }

    @FXML
    private void Add(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddPeriodeChasse.fxml"));
        Parent root = loader.load();
        PeriodeChasseList.getScene().setRoot(root);
        AddPeriodeChasseController aac = loader.getController();
        if (pplist.size()>0){
            aac.lastIdPeriode=periodeTest.getIdP();
        }
    }

    @FXML
    private void GoToArticle(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        PeriodeChasseList.getScene().setRoot(root);
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
         if(PeriodeChasseList.getSelectionModel().getSelectedItem() != null){
            PeriodeChasse  pc = PeriodeChasseList.getSelectionModel().getSelectedItem();
            EditPeriodeChasseController.idP = pc.getIdP();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditPeriodeChasse.fxml"));
            Parent root = loader.load();
            PeriodeChasseList.getScene().setRoot(root);
            EditPeriodeChasseController epc = loader.getController();
            epc.dateDebutPicker.setValue(pc.getDateDebut());
            epc.dateFinPicker.setValue(pc.getDateFin());
            epc.adresseField.setText(pc.getAdresse());
            epc.superficieField.setText(Integer.toString(pc.getSuperficie()));
        }
    }

    @FXML
    private void Delete(ActionEvent event) throws SQLException {
        if(PeriodeChasseList.getSelectionModel().getSelectedItem() != null){
            PeriodeChasseService pcs = new PeriodeChasseService();
            PeriodeChasse pc = PeriodeChasseList.getSelectionModel().getSelectedItem();
            pcs.supprimerPeriodeChasse(pc.getIdP());
            Load();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("The periode chasse was deleted successfully");
            alert.showAndWait();
        }
    }
    @FXML
    private void Cancel(ActionEvent event) {
        Load();
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        PeriodeChasseList.getScene().setRoot(root);
    }
    
}
