/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.AddProduitNeufController.lastId;
import static GUI.EditUserController.id;
import Models.User;
import Services.UserService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author user
 */
public class EditFrontController implements Initializable {
    protected static User user;
    @FXML
    protected TextField usernameText;
    @FXML
    protected TextField mdpText;
    @FXML
    protected TextField emailText;
    @FXML
    private Button saveButton;
    
    protected static int id;
    @FXML
    private Button cancelButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        UserService us = new UserService();
        us.updateUser(id,usernameText.getText(),emailText.getText(),"N;");
        HomeController.user = us.showOneUser(usernameText.getText());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        usernameText.getScene().setRoot(root);
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        usernameText.getScene().setRoot(root);
    }
}
