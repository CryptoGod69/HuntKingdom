/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Services.ArticleService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class StatistiqueController implements Initializable {

    @FXML
    private PieChart pieChart;
    @FXML
    private Button cancelButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       ArticleService as = new ArticleService();
       int foretA = as.CountX(as.rechercherArticleCategorie("foret"));
       int volA = as.CountX(as.rechercherArticleCategorie("vol"));
       int MontagneA = as.CountX(as.rechercherArticleCategorie("montagne"));
       ObservableList<PieChart.Data> pieChartData=FXCollections.observableArrayList(
       new PieChart.Data("Foret",foretA),new PieChart.Data("Vol",volA),new PieChart.Data("Montagne",MontagneA));
       pieChart.setData(pieChartData);
    }    

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        cancelButton.getScene().setRoot(root);
    }
    
}
