/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.User;
import Services.UserService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AddUserController implements Initializable {

    @FXML
    private TextField usernameText;
    @FXML
    private TextField emailText;
    @FXML
    private Button cancelButton;
    @FXML
    private DatePicker ddnText;
    @FXML
    private TextField mdp1Text;
    @FXML
    private TextField mdp2Text;
    @FXML
    private Button signUpButton;
    @FXML
    private Button addPictureButton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();
        usernameText.getScene().setRoot(root);
        ShowUserController spc = loader.getController();
    }

    @FXML
    private void SignUp(ActionEvent event) throws SQLException, IOException {
        UserService us = new UserService();
        boolean test = mdp1Text.getText().equals(mdp2Text.getText());
        if (test=true)
        {   
            User u = new User();
            u.setEmail(emailText.getText());
            u.setUsername(usernameText.getText());
            u.setPassword(mdp1Text.getText());
            u.setRoles("N;");
            us.addUser(u);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();
            usernameText.getScene().setRoot(root);
        }
        else{
            System.out.println("Please enter the same password");
        }
    }

    @FXML
    private void AddPicture(ActionEvent event) {
        int lastIdU = 0;
        UserService us = new UserService();
        ObservableList<User> ulist = us.showUsersList();
        if(ulist.size()!=0){
            User u = ulist.get(ulist.size()-1);
            lastIdU = u.getId()+1;
        }else{
            lastIdU++;
        }
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/users"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG", "*.jpg"),new FileChooser.ExtensionFilter("JPEG", "*.jpeg"));
        File selectedFile = fc.showSaveDialog(null);
        
        if (selectedFile != null){
            String path = "";
            path = selectedFile.getAbsolutePath();
            //Image image = new Image(getClass().getResource(path).toExternalForm()); 
            //image = imgTest;
            File nouveau = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/users/"+lastIdU+".jpg");
            selectedFile.renameTo(nouveau);
        }
    }

   
    
}
