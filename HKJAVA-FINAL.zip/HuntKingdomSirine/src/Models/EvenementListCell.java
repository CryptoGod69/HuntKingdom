/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Services.UserService;
import java.io.File;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author mouradsmac
 */
public class EvenementListCell extends ListCell<Evenement>{
    
    private final GridPane gridPane = new GridPane(); 
    
    private final Label titleLabel = new Label();
    private final Label orgaLabel = new Label(); 
    private final Label lieuLabel = new Label(); 
    private final Label descLabel = new Label(); 
    private final Label typeLabel = new Label(); 
    private final Label dateLabel = new Label();
    private final Label nbrPartLabel = new Label();
    private final Label CmpPartLabel = new Label();

    private final ImageView eventIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public EvenementListCell() { 
        eventIcon.setFitWidth(20); 
        eventIcon.setPreserveRatio(true); 
        GridPane.setConstraints(eventIcon, 0, 0, 1, 3); 
        GridPane.setValignment(eventIcon, VPos.TOP); 
        // 
        titleLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(titleLabel, 1, 0); 
        // 
        dateLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(dateLabel, 2, 0); 
        //
        orgaLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(orgaLabel, 0, 1); 
        
         typeLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(typeLabel, 1, 1); 
        
        CmpPartLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(CmpPartLabel, 2, 1); 
        
        lieuLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(lieuLabel, 0, 2); 
        
        descLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(descLabel, 1, 2); 
        
        nbrPartLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(nbrPartLabel, 2, 2); 
        //                 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(eventIcon, nbrPartLabel, descLabel, lieuLabel,CmpPartLabel,typeLabel,orgaLabel,dateLabel,titleLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override 
    protected void updateItem(Evenement event, boolean empty) { 
        super.updateItem(event, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && event != null) { 
            
            titleLabel.setText(event.getTitre() );
            orgaLabel.setText("Orga :"+ event.getOrganisateur());
            lieuLabel.setText("Lieu :"+event.getLieu() ); 
            descLabel.setText("Desc :"+event.getDescription());
            typeLabel.setText("Type :"+event.getType());
            nbrPartLabel.setText("Nbr Max :" +Integer.toString(event.getNbrPart()));
            dateLabel.setText("Date : " +event.getDate().toString());
            CmpPartLabel.setText("Nbr Part :" +Integer.toString(event.getCmpPart()));
            
            String path = "/Resources/users/0.png";
            UserService us = new UserService();
            User u = us.showUsername(event.getOrganisateur());
            File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/users/"+u.getId()+".jpg");
            if(tmp.exists()){
                path = "/Resources/users/"+u.getId()+".jpg";
            }
            
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
                eventIcon.setImage(image);
            }
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}
