/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Omar
 */
public class TopicListCell extends ListCell<Topic>{
    private final GridPane gridPane = new GridPane(); 
    private final Label titleLabel = new Label(); 
    private final Label authorLabel = new Label();
    private final Label lastPostDateLabel = new Label();
    private final Label stateLabel = new Label(); 
    private final Label nbPostsLabel = new Label();
    private final ImageView stateIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public TopicListCell() { 
        stateIcon.setFitWidth(45); 
        stateIcon.setPreserveRatio(true); 
        GridPane.setConstraints(stateIcon, 0, 0, 1, 3); 
        GridPane.setValignment(stateIcon, VPos.TOP); 
        // 
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 1.5em;"); 
        GridPane.setConstraints(titleLabel, 1, 0); 
        // 
        stateLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(stateLabel, 2, 0); 
        //
        nbPostsLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(nbPostsLabel, 3, 0); 
        //
        authorLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(authorLabel, 1, 1); 
        //         
        lastPostDateLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(lastPostDateLabel, 2, 1); 
        //         
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(stateIcon, titleLabel, authorLabel, lastPostDateLabel, stateLabel, nbPostsLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override 
    protected void updateItem(Topic item, boolean empty) { 
        super.updateItem(item, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && item != null) { 
            titleLabel.setText(item.getTitle()); 
            authorLabel.setText(item.getAuthor()); 
            lastPostDateLabel.setText(item.getLastPostDate().toString()); 
            stateLabel.setText(item.getState());
            nbPostsLabel.setText(Integer.toString(item.getNbPosts()));
            String path = "";
            if(item.getState().equals("open")){
                path = "/Resources/open.png";
            }else if(item.getState().equals("solved")){
                path = "/Resources/solved.png";
            }
            Image image = new Image(getClass().getResource(path).toExternalForm());
            stateIcon.setImage(image);
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY); 
        } 
    }
}
