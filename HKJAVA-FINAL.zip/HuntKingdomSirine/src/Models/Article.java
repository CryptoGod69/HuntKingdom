/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Legion
 */
public class Article {
    private int IdA;
    private String categorie;
    private String titre;
    private String sousTitre;
    private String chapeau;
    private String texte;
    private int nbLikes=0;
 

    public Article() {
    }
    
    public Article(String categorie, String titre, String sousTitre, String chapeau, String texte) {
        this.categorie = categorie;
        this.titre = titre;
        this.sousTitre = sousTitre;
        this.chapeau = chapeau;
        this.texte = texte;
    }
    
    public int getIdA() {
        return IdA;
    }

    public String getCategorie() {
        return categorie;
    }

    public String getTitre() {
        return titre;
    }

    public String getSousTitre() {
        return sousTitre;
    }

    public String getChapeau() {
        return chapeau;
    }

    public String getTexte() {
        return texte;
    }

    public int getNbLikes() {
        return nbLikes;
    }
    

    public void setIdA(int IdA) {
        this.IdA = IdA;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }
    
    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setSousTitre(String sousTitre) {
        this.sousTitre = sousTitre;
    }

    public void setChapeau(String chapeau) {
        this.chapeau = chapeau;
    }

    public void setTexte(String texte) {
        this.texte = texte;
    }

    public void setNbLikes(int nbLikes) {
        this.nbLikes = nbLikes;
    }
    
    @Override
    public String toString() {
        return "Article{" + "IdA=" + IdA + ", categorie=" + categorie + ", titre=" + titre + ", sousTitre=" + sousTitre + ", chapeau=" + chapeau + ", texte=" + texte + '}';
    }

    
    
    
}
