/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Models.Topic;
import Utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Omar
 */
public class TopicService {
    Connection cnx = DataSource.getInstance().getCnx();
    
    public int getLastTopicId() {
        int id = 0;
        String requete = "select * from topic order by id desc limit 1";
            try{
                Statement st = cnx.createStatement();
                ResultSet rs = st.executeQuery(requete);
                while(rs.next()) {
                    id = rs.getInt(1);
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
            }
        return id;
    }
    
    //Ajouter topic1 DONE
    public void createTopic(Topic t) throws SQLException{
        List<Topic> T = readTopicList();
        if(!T.contains(t)) {
            String requete = "insert into topic (id,title,author,nbPosts,lastPostDate,state) values ('"+t.getId()+"','"+t.getTitle()+"','"+t.getAuthor()+"','"+t.getNbPosts()+"',now(),'"+t.getState()+"')";
            try{
                Statement st = cnx.createStatement();
                st.executeUpdate(requete);
                System.out.println("Topic posted successfully");
            } catch (SQLException ex) {
                Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    //Ajouter topic2 DONE
    public int createTopic2(Topic t) throws SQLException {
        List<Topic> T = readTopicList();
        if(!T.contains(t)) {
            String requete = "insert into topic (id,title,author,nbPosts,lastPostDate,state) values ('"+t.getId()+"','"+t.getTitle()+"','"+t.getAuthor()+"','"+t.getNbPosts()+"',now(),'"+t.getState()+"')";
            try {
                PreparedStatement pst = cnx.prepareStatement(requete);
                pst.setInt(1,t.getId());
                pst.setString(2,t.getTitle());
                pst.setString(3, t.getAuthor());
                pst.setInt(4, t.getNbPosts());
                pst.setTimestamp(5, t.getLastPostDate());
                pst.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return getLastTopicId();
    }
    
    //Afficher tout les topics DONE
    public ObservableList<Topic> readTopicList(){
        ObservableList<Topic> topicList = FXCollections.observableArrayList();
        String requete = "select * from topic";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                Topic t = new Topic();
                t.setId(rs.getInt(1));
                t.setTitle(rs.getString(2));
                t.setAuthor(rs.getString(3));
                t.setNbPosts(rs.getInt(4));
                t.setLastPostDate(rs.getTimestamp(5));
                t.setState(rs.getString(6));
                topicList.add(t);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return topicList;
    }
    
    //Afficher un topic avec id DONE
    public Topic readTopic(int id){
        Topic t = new Topic();
        String requete = "select * from topic where id="+id;
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                t.setId(rs.getInt(1));
                t.setTitle(rs.getString(2));
                t.setAuthor(rs.getString(3));
                t.setNbPosts(rs.getInt(4));
                t.setLastPostDate(rs.getTimestamp(5));
                t.setState(rs.getString(6));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return t;
    }
    
    //Supprimer tout les posts d'un topic DONE
    public void deletePostTopic(int topicId) {
        String requete = "delete from post where topicId="+topicId;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Supprimer un topic, y compris les posts qu'il contient DONE
    public void deleteTopic(int id) {
        deletePostTopic(id);
        String requete = "delete from topic where id="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Topic and post deleted successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Modifier topic avec id DONE
    public void updateTopic(int id, String title, String author) {
        String requete = "update topic set title='"+title+"', author='"+author+"' where id="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Topic updated successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Changer etat topic
    public void switchState(int id) {
        String requete = "select * from topic where id="+id;
        String state = "";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                state = rs.getString(6);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //switching
        if(state.equals("open")){
            state = "solved";
        }else if(state.equals("solved")){
            state = "open";
        }
        
        requete = "update topic set state='"+state+"' where id="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Topic state switched successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}