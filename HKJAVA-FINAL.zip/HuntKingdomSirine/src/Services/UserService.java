/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;


import Models.User;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Utils.DataSource;
import java.sql.Date;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import Utils.DataSource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 *
 * @author Mourad
 */
public class UserService {
    
    Connection cnx = DataSource.getInstance().getCnx(); 
    public void addUser(User u) throws SQLException{
       
        int id=u.getId();
        String password=u.getPassword();
        String email=u.getEmail();
        String username=u.getUsername();
        String requete = "INSERT into  fos_user_table (id,username,username_canonical,email,email_canonical,enabled,password) values ('"+id+"','"+username+"','"+username+"','"+email+"','"+email+"','"+1+"','"+password+"')";
        System.out.println(requete);
        try{
            Statement st = cnx.createStatement();
            //st.executeUpdate(requete);
            System.out.println("User added successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
       public void removeUser(int id) throws SQLException{
                   
        String requete = "DELETE FROM fos_user_table WHERE id="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("User deleted successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       
       public User showOneUser(String username){
       //System.out.println(id);
       User u = new User();
           String requete = "SELECT * FROM fos_user_table WHERE username="+'"'+username+'"';    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      //u.setLastName(rs.getString(2));
                      //u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      //u.setPhone(rs.getInt(6)); 
                      //u.setRole(rs.getString(7));
                      //u.setBirthDate(rs.getDate(8).toLocalDate()); 
                      //System.out.println(id);
                      //System.out.println(u);
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
       
    public User showEmail(String email){
       
       User u = new User();
           String requete = "SELECT * FROM fos_user_table WHERE email='"+email+"'";
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      //u.setLastName(rs.getString(2));
                      //u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      //u.setPhone(rs.getInt(6)); 
                      //u.setRole(rs.getString(7));
                      //u.setBirthDate(rs.getDate(8).toLocalDate()); 
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
     
    public User showUsername(String username){
       User u = new User();
        String requete = "SELECT * FROM fos_user_table WHERE username='"+username+"'";
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      //u.setLastName(rs.getString(2));
                      //u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      //u.setPhone(rs.getInt(6)); 
                      //u.setRole(rs.getString(7));
                      //u.setBirthDate(rs.getDate(8).toLocalDate()); 
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
    /**
     *
     * @return
     * @throws SQLException
     */
    public ObservableList<User> showUsersList(){
       
        ObservableList<User> listUsers = FXCollections.observableArrayList(); 
        String requete = "SELECT * FROM fos_user_table";    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      User u = new User();
                      u.setId(rs.getInt(1));
                      u.setUsername(rs.getString(2));
                      u.setEmail(rs.getString(4)); 
                      u.setPassword(rs.getString(8)); 
                      u.setRoles(rs.getString(12));
                      listUsers.add(u);               
          }                        
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return listUsers;
    }
 
    
 
   
   public void updateUser (int id,String username,String email,String roles)
     {
             String requete="UPDATE fos_user_table SET username='"+username+"',email='"+email+"',roles='"+roles+"'WHERE id="+id;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("User updated successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

