<?php

namespace ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RendezVousType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder->add('acheteur')->add('vendeur')->add('date',DateType::class, array(
            'widget' => 'choice',
            'years' => range(date('Y'), date('Y')+100),
            'months' => range(date('m'), 12),
            'days' => range(date('d'), 31),
        ))->add('heure')->add('lieu', ChoiceType::class, [
        'choices'  => [
            '' => null,
            'Ariana' => true,
            'Ben arous' => true, 'Bizerte' => true, 'Beja' => true, 'Gabes' => false, 'Gafsa' => false, 'Jendouba' => false, 'Kairouan' => false, 'La manouba' => false, 'Mahdia' => false, 'Sfax' => false, 'Sousse' => false, 'Nabeul' => false, 'Tunis' => false,

        ],
    ]);
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'ProductBundle\Entity\RendezVous'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'productbundle_rendezvous';
    }


}
