<?php

namespace ProductBundle\Form;

use Cassandra\Type\UserType;
use Doctrine\ORM\Query\AST\SelectExpression;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProductOccType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('proprietaire')->add('nom')->add('categorie', ChoiceType::class, [
        'choices'  => [
            '' => null,
            'Arme' => true,
            'Vetements' => true,
            'Nourriture' => false,

        ],
    ])->add('description')->add('etat')->add('dateachat', DateType::class, [
            'widget' => 'single_text',
            'format' => 'yyyy-MM-dd',
        ])->add('image',FileType::class,array('label'=>'insert image'))->add('prix');
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'ProductBundle\Entity\ProductOcc'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'productbundle_productocc';
    }


}
