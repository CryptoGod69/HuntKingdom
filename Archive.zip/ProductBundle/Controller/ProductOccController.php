<?php

namespace ProductBundle\Controller;

use ProductBundle\Entity\LikesProd;
use ProductBundle\Entity\CommentProduct;
use ProductBundle\Entity\mail;
use ProductBundle\Entity\ProductOcc;
use ProductBundle\Entity\RatingProduct;
use ProductBundle\ProductBundle;
use Swift_Message;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use ProductBundle\Form\CommentProductType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

/**
 * Productocc controller.
 *
 * @Route("productocc")
 */
class ProductOccController extends Controller
{
    /**
     * Lists all productOcc entities.
     *
     * @Route("/", name="productocc_index")
     * @Method("GET")
     */

    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $queryBuilder=$em->getRepository('ProductBundle:ProductOcc')->createQueryBuilder('p');
        if ($request->query->getAlnum('filter')) {
            $productOccs=$queryBuilder->where('p.nom LIKE :nomProd')
                ->setParameter('nomProd', '%' . $request->query->getAlnum('filter') . '%')
                ->getQuery()
                ->getResult();
        }
        $productOccs = $em->getRepository('ProductBundle:ProductOcc')->findAll();
        return $this->render("productocc/index.html.twig", array( 'productOccs' => $productOccs

        ));


        // $em = $this->getDoctrine()->getManager();

     /*
        /**
         * @var $paginator \Knp\Component\Pager\Paginator
         * */

      /*
        $paginator=$this->get('knp_paginator');
        $result=$paginator->paginate(
            $productOccs,
            $request->query->getInt('page',1),
            $request->query->getInt('limit',3)
        );
*/

    }



    /**
     * Creates a new productOcc entity.
     *
     * @Route("/new", name="productocc_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {

        $productOcc = new Productocc();
        $form = $this->createForm('ProductBundle\Form\ProductOccType', $productOcc);
        $form->handleRequest($request);
        $user=$this->getUser();
        if ($form->isSubmitted() && $form->isValid()) {
            $file=$productOcc->getImage();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('image_directory'),$fileName
           );
            $productOcc->setImage($fileName);

            $em = $this->getDoctrine()->getManager();
            $em->persist($productOcc);
            $em->flush();

            return $this->redirectToRoute('productocc_show', array('id' => $productOcc->getId()));
        }

        return $this->render('productocc/new.html.twig', array(
            'productOcc' => $productOcc,
            'form' => $form->createView(),'user'=>$user
        ));
    }

    /**
     * Finds and displays a productOcc entity.
     * Add commentProduct on productOcc
     *
     * @Route("/{id}", name="productocc_show")
     * @Method("POST")
     */
    public function showAction(ProductOcc $productOcc,Request $request,$id)
    {
        //afficher produit plus nombre de vues
       // $deleteForm = $this->createDeleteForm($productOcc);

        $em = $this->getDoctrine()->getManager();
        $productOccs = $em->getRepository('ProductBundle:ProductOcc')->find($id);
        $productOccs->setNbVue($productOccs->getNbVue()+1);
        $em->persist($productOccs);
        $em->flush();

        //affichage commentaire
        $commentProducts = $em->getRepository('ProductBundle:CommentProduct')->findBy(array('produit' => $id));

      //ajouter commentaire

         $user = $this->getUser();

        if ($request->getMethod() == 'POST') {
            $emp = $this->getDoctrine()->getManager();
            $dateNow = new \DateTime('now');
            $contenu = $request->get('contenu');
                $add_comment = new CommentProduct($contenu,$productOcc,$user,$dateNow);
                try {
                    $emp->persist($add_comment);
                    $emp->flush();
                } catch (\Exception $e) {
                    //
                }
           return $this->redirectToRoute('productocc_show', array('id' => $productOccs->getId()));
        }

        return $this->render('productocc/show.html.twig', array(
          //  'productOcc' => $productOcc,
            'productOcc' => $productOccs,
          //   'delete_form' => $deleteForm->createView(),
            'commentProducts' => $commentProducts, //affichage commentaire

        ));


    }
      function deleteCAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $comment = $em->getRepository(CommentProduct::class)->find($id);
        $em2 = $this->getDoctrine()->getManager();
        $productOccs = $em2->getRepository('ProductBundle:ProductOcc')->find($id);
        $em->remove($comment);
        $em->flush();
        return $this->redirectToRoute("productocc_index"
        );

    }


    /**
     * Displays a form to edit an existing productOcc entity.
     *
     * @Route("/{id}/edit", name="productocc_edit")
     * @Method({"GET", "POST"})
     */

    public function editAction(Request $request, ProductOcc $productOcc)
    {
        $deleteForm = $this->createDeleteForm($productOcc);
        $editForm = $this->createForm('ProductBundle\Form\ProductOccType', $productOcc);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('productocc_edit', array('id' => $productOcc->getId()));
        }

        return $this->render('productocc/edit.html.twig', array(
            'productOcc' => $productOcc,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    function deleteAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $produit = $em->getRepository(ProductOcc::class)->find($id);

        $em->remove($produit);
        $em->flush();
        return $this->redirectToRoute("productocc_index"
        );

    }
    /* /**
     * Deletes a productOcc entity.
     *
     * @Route("/{id}", name="productocc_delete")
     * @Method("DELETE")
     */
  /* public function deleteAction(Request $request, ProductOcc $productOcc)
    {
        $form = $this->createDeleteForm($productOcc);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($productOcc);
            $em->flush();
        }

        return $this->redirectToRoute('productocc_index');
    } */

    /**
     * Creates a form to delete a productOcc entity.
     *
     * @param ProductOcc $productOcc The productOcc entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(ProductOcc $productOcc)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('productocc_delete', array('id' => $productOcc->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
    /**
     * Lists all commentProduct entities.
     *
     * @Route("", name="commentproduct_index")
     * @Method("GET")
     */

    public function detailsAction(Request $request,ProductOcc $produit, $id)
    {

        $user = $this->getUser();
        $add_comment = new CommentProduct();
        $em = $this->getDoctrine()->getManager();
        $commentProduct = $em->getRepository(CommentProduct::class)->findByProduct($produit);
        $add_comment->setProduit($produit);
        $add_comment->setUser($user);
        $add_comment->setDateC(new \DateTime());
        $form = $this->createFormBuilder($add_comment)
            ->add('contenu', TextareaType::class)
            ->getForm();

        if ($request->getMethod() == 'POST') {
            $form->handleRequest($request);

            if ($form->isSubmitted() && $form->isValid()) {
                $add_comment = $form->getData();
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($add_comment);
                $em->flush();

                return $this->redirectToRoute('productocc_show', array('id' => $produit->getId()));


            }
        }
        return $this->render('productocc/show.html.twig', array(
            'productOcc' => $produit,
            'form' => $form->createView(),
            'comment' => $add_comment,
            'commentProduct' => $commentProduct,

        ));
    }


    public function sendMailAction (Request $request)
    {
     $mail = new mail();
        $form = $this->createForm('ProductBundle\Form\mailType', $mail);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
          $subject=$mail->getSubject();
          $mail=$mail->getMail();
          $object=$request->get('form')['object'];
            $username="feryeld@gmail.com";
            $message = (new \Swift_Message())
                ->setSubject($subject)
                ->setFrom($username)
                ->setTo($mail)
                ->setBody($object);
                $this->get('mailer')->send($message);
               // $this->get('session')->getFlashBag()->add('notice','message envoye avec succes');
               $this->addFlash('message','message envoye avec succes');

        }
        return $this->render('@Product/Default/sendmail.html.twig',array('f'=> $form->createView()));
    }

    /**
     * Like Product
     * @Route("/{id}", name="productocc_like")
     *
     */
    public function likeProdAction(Request $request,ProductOcc $produit,  $id)
    {
        if($this->getUser() == null){
            return $this->redirectToRoute( "login_page" );
        }
        $em = $this->getDoctrine()->getManager();
        $likeVar = new LikesProd();
        $user = $this->getUser()->getId();
        $username = $this->getUser();

        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(LikesProd::class);
        $prod = $em->getRepository( ProductOcc::class)->find($id);
        $likes = $repository->getifLiked($user,$id);
        $var= $prod->getProdLikes();
       if (count( $likes) > 0)
        {
            $prod->setProdLikes($var-1);
            $em->remove($likes[0]);
            $em->flush();
            return new Response('Like Removed ;)');

        }else {

            $likeVar->setIdProdLike($id);
            $likeVar->setIdUserLike($user);
            $likeVar->setNomUserLike($username);
            $prod->setProdLikes($var + 1);
            var_dump($prod->getProdLikes());
            $em->persist($likeVar);
            $em->flush();
           return $this->redirectToRoute('productocc_show', array('id' => $produit->getId()));

    }
        /**
         * switch etat
         * @Route("/{id}", name="productocc_switch")
         *
         */
    }
    public function switchAction(ProductOcc $produit, $id)
    {   $em = $this->getDoctrine()->getManager();
        $produit = $em->getRepository('ProductBundle:ProductOcc')->findOneBy(array('id' => $id));

        if($produit->getEtat() == "Réservé"){
            $produit->setEtat("vendu");
        }else if($produit->getEtat() == "vendu"){
            $produit->setEtat("disponible");
        }


        try {
            $em->flush();
        } catch (\Exception $e) {
            //
        }
        return $this->redirectToRoute('productocc_show', array('id' => $produit->getId()));
    }

    public function getMaxLikesAction(){
        $ProdLikes = 'ProdLikes';
        $em = $this->getDoctrine()->getManager();
        $productOccs = $em->getRepository('ProductBundle:ProductOcc')->findAll();
        $max = max(array_map(function($p) use ($ProdLikes) {
            return $p->$ProdLikes;
        },
        $productOccs));
        $produit = $em->getRepository('ProductBundle:ProductOcc')->findOneBy(array('ProdLikes' => $max));
        return $produit;
    }
}
