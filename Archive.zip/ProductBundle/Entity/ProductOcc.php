<?php

namespace ProductBundle\Entity;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints\Date;

/**
 * ProductOcc
 *
 * @ORM\Table(name="product_occ")
 * @ORM\Entity(repositoryClass="ProductBundle\Repository\ProductOccRepository")
 */
class ProductOcc
{

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @var int $nbVue
     *
     * @ORM\Column(name="nbVue", type="integer", length=100)
     */
    private $nbVue=0;
    /**
     *  Get id
     * @return int
     */
    public function getNbVue()
    {
        return $this->nbVue;
    }

    /**
     * Set nbVue
     *
     * @param int $nbVue
     *
     * @return ProductOcc
     */
    public function setNbVue($nbVue)
    {
        $this->nbVue = $nbVue;
    }


    /**
     * @var string
     *
     * @ORM\Column(name="Proprietaire", type="string", length=255)
     */
    private $proprietaire;

    /**
     * @var string
     *
     * @ORM\Column(name="Nom", type="string", length=255)
     * @Assert\NotBlank(message="Le champ nom est obligatoire")
     * @Assert\Length(
     *     min = 5,
     *     max = 50,
     *     minMessage = "Le nom doit contenir au minimum 5 carracteres",
     *     maxMessage = "Le nom doit contenir au maximum 50 carracteres"
     * )
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="Categorie", type="string", length=255)
     */
    private $categorie;

    /**
     * @var string
     *
     * @ORM\Column(name="Description", type="string", length=255)
     *  @Assert\NotBlank(message="Le champ description est obligatoire")
     */
    private $description;


    /**
     * @var string
     *
     * @ORM\Column(name="Prix", type="string", length=255)
     */
    private $image;

    /**
     * @var string
     *
     * @ORM\Column(name="Image", type="string", length=255)
     * @Assert\NotBlank(message="Le champ prix est obligatoire")
     * @Assert\GreaterThan(
     *     value=0,
     *     message="Le prix doit être supérieur à 0"
     * )
     */
    private $prix;
    /**
     * @var string
     *
     * @ORM\Column(name="Etat", type="string", length=255)
     *
     */
    private $etat="disponible";
    /**
     * @var int
     *
     * @ORM\Column(name="ProdLikes")
     *
     */
    private $ProdLikes=0;

    /**
     * @return int
     */
    public function getProdLikes()
    {
        return $this->ProdLikes;
    }

    /**
     * @param int $ProdLikes
     */
    public function setProdLikes($ProdLikes)
    {
        $this->ProdLikes = $ProdLikes;
    }
    /**
     * @var date
     *
     * @ORM\Column(name="DateAchat", type="date",nullable=true)
     */
    private $dateAchat;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set proprietaire
     *
     * @param string $proprietaire
     *
     * @return ProductOcc
     */
    public function setProprietaire($proprietaire)
    {
        $this->proprietaire = $proprietaire;

        return $this;
    }

    /**
     * Get proprietaire
     *
     * @return string
     */
    public function getProprietaire()
    {
        return $this->proprietaire;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return ProductOcc
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set categorie
     *
     * @param string $categorie
     *
     * @return ProductOcc
     */
    public function setCategorie($categorie)
    {
        $this->categorie = $categorie;

        return $this;
    }

    /**
     * Get categorie
     *
     * @return string
     */
    public function getCategorie()
    {
        return $this->categorie;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return ProductOcc
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param string $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * Set prix
     *
     * @param string $prix
     *
     * @return ProductOcc
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     *
     * @return string
     */
    public function getPrix()
    {
        return $this->prix;
    }

    /**
     * @return string
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * @param string $etat
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;
    }

    /**
     * @return Date
     */
    public function getDateAchat()
    {
        return $this->dateAchat;
    }

    /**
     * @param Date $dateAchat
     */
    public function setDateAchat($dateAchat)
    {
        $this->dateAchat = $dateAchat;
    }

    public function __toString()
    {
        return $this->nom;
    }
}

