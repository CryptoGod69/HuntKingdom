<?php

namespace ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CommentProduct
 *
 * @ORM\Table(name="comment_product")
 * @ORM\Entity(repositoryClass="ProductBundle\Repository\CommentProductRepository")
 */
class CommentProduct
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="contenu", type="text")
     */
    private $contenu;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateC", type="datetime")
     */
    private $dateC;

    /**
     * @ORM\ManyToOne(targetEntity="ProductOcc")
     * @ORM\JoinColumn(name="prod_id",referencedColumnName="id")
     */
    private $produit;

    /**
     * @ORM\ManyToOne(targetEntity="User\UserBundle\Entity\User")
     * @ORM\JoinColumn(name="user_id",referencedColumnName="id")
     */
    private $user;

    /**
     * CommentProduct constructor.
     * @param string $contenu
     * @param \DateTime $dateC
     * @param $produit
     * @param $user
     */
    public function __construct($contenu, $produit, $user,$dateC)
    {
        $this->contenu = $contenu;
        $this->produit = $produit;
        $this->user = $user;
        $this->dateC = $dateC;
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set contenu
     *
     * @param string $contenu
     *
     * @return CommentProduct
     */
    public function setContenu($contenu)
    {
        $this->contenu = $contenu;

        return $this;
    }

    /**
     * Get contenu
     *
     * @return string
     */
    public function getContenu()
    {
        return $this->contenu;
    }

    /**
     * Set dateC
     *
     * @param string $dateC
     *
     * @return CommentProduct
     */
    public function setDateC($dateC)
    {
        $this->dateC = $dateC;

        return $this;
    }

    /**
     * Get dateC
     *
     * @return string
     */
    public function getDateC()
    {
        return $this->dateC;
    }

    /**
     * Set produit
     *
     * @param string $produit
     *
     * @return CommentProduct
     */
    public function setProduit($produit)
    {
        $this->produit = $produit;

        return $this;
    }

    /**
     * Get produit
     *
     * @return string
     */
    public function getProduit()
    {
        return $this->produit;
    }

    /**
     * Set user
     *
     * @param string $user
     *
     * @return CommentProduct
     */
    public function setUser($user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return string
     */
    public function getUser()
    {
        return $this->user;
    }
    public function __toString()
    {
        return $this->id;
    }
}

