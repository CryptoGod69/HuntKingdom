<?php

namespace ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RatingProduct
 *
 * @ORM\Table(name="rating_product")
 * @ORM\Entity(repositoryClass="ProductBundle\Repository\RatingProductRepository")
 */
class RatingProduct
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="note", type="integer")
     */
    private $note;


    /**
     * @ORM\ManyToOne(targetEntity="User\UserBundle\Entity\User")
     */
    private $user;

    /**
     * @ORM\ManyToOne(targetEntity="ProductOcc")
     */
    private $produit;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set note
     *
     * @param integer $note
     *
     * @return RatingProduct
     */
    public function setNote($note)
    {
        $this->note = $note;

        return $this;
    }

    /**
     * Get note
     *
     * @return int
     */
    public function getNote()
    {
        return $this->note;
    }

    /**
     * Set user
     *
     * @param User\UserBundle\Entity\User $user
     *
     * @return RatingProduct
     */
    public function setUser(User\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return User\UserBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set produit
     *
     *  @param \ProductBundle\Entity\ProductOcc $produit
     *
     * @return RatingProduct
     */
    public function setProduit(\ProductBundle\Entity\ProductOcc $produit=null)
    {
        $this->produit = $produit;

        return $this;
    }

    /**
     * Get produit
     *
     * @return \ProductBundle\Entity\ProductOcc
     */
    public function getProduit()
    {
        return $this->produit;
    }
}

