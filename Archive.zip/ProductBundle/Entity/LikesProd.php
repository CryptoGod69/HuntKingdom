<?php

namespace ProductBundle\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * LikesProd
 *
 * @ORM\Table(name="likes_prod")
 * @ORM\Entity(repositoryClass="ProductBundle\Repository\LikesProdRepository")
 */
class LikesProd
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="idUserLike", type="string", length=255)
     */
    private $idUserLike;

    /**
     * @var string
     *
     * @ORM\Column(name="idProdLike", type="string", length=255)
     */
    private $idProdLike;

    /**
     * @var string
     *
     * @ORM\Column(name="nomUserLike", type="string", length=255)
     */
    private $nomUserLike;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idUserLike
     *
     * @param string $idUserLike
     *
     * @return LikesProd
     */
    public function setIdUserLike($idUserLike)
    {
        $this->idUserLike = $idUserLike;

        return $this;
    }

    /**
     * Get idUserLike
     *
     * @return string
     */
    public function getIdUserLike()
    {
        return $this->idUserLike;
    }

    /**
     * Set idProdLike
     *
     * @param string $idProdLike
     *
     * @return LikesProd
     */
    public function setIdProdLike($idProdLike)
    {
        $this->idProdLike = $idProdLike;

        return $this;
    }

    /**
     * Get idProdLike
     *
     * @return string
     */
    public function getIdProdLike()
    {
        return $this->idProdLike;
    }

    /**
     * Set nomUserLike
     *
     * @param string $nomUserLike
     *
     * @return LikesProd
     */
    public function setNomUserLike($nomUserLike)
    {
        $this->nomUserLike = $nomUserLike;

        return $this;
    }

    /**
     * Get nomUserLike
     *
     * @return string
     */
    public function getNomUserLike()
    {
        return $this->nomUserLike;
    }
}