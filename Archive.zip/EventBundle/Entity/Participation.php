<?php

namespace EventBundle\Entity;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;


use Doctrine\ORM\Mapping as ORM;

/**
 * Participation
 *
 * @ORM\Table(name="participation")
 * @ORM\Entity(repositoryClass="EventBundle\Repository\ParticipationRepository")
 *
 * @UniqueEntity( fields={"idUser", "idEvent"}, errorPath="game", message="This game is already added on this user stack.")
 */
class Participation
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="idUser", type="integer")
     */
     protected $idUser;

    /**
     * @var int
     *
     * @ORM\Column(name="idEvent", type="integer")
     */
    private $idEvent;


    /**
     * @var string
     *
     * @ORM\Column(name="partEvent", type="string", length=255)
     */
    private $partEvent;



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idUser
     *
     * @param integer $idUser
     *
     * @return Participation
     */
    public function setIdUser($idUser)
    {
        $this->idUser = $idUser;

        return $this;
    }

    /**
     * Get idUser
     *
     * @return int
     */
    public function getIdUser()
    {
        return $this->idUser;
    }

    /**
     * Set idEvent
     *
     * @param integer $idEvent
     *
     * @return Participation
     */
    public function setIdEvent($idEvent)
    {
        $this->idEvent = $idEvent;

        return $this;
    }

    /**
     * Get idEvent
     *
     * @return int
     */
    public function getIdEvent()
    {
        return $this->idEvent;
    }

    /**
     * @return string
     */
    public function getPartEvent()
    {
        return $this->partEvent;
    }

    /**
     * @param string $partEvent
     */
    public function setPartEvent($partEvent)
    {
        $this->partEvent = $partEvent;
    }

}

