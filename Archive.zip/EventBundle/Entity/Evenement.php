<?php

namespace EventBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Evenement
 *
 * @ORM\Table(name="Evenement")
 * @ORM\Entity(repositoryClass="EventBundle\Repository\EvenementRepository")
 */
class Evenement
{
    /**
     * @var int
     *
     * @ORM\Column(name="idEvent", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $idEvent;

    /**
     * @var string
     *
     * @ORM\Column(name="Titre", type="string", length=255)
     */
    private $titreEvent;

    /**
     * @var string
     *
     * @ORM\Column(name="Organisateur", type="string", length=255)
     */
    private $orgaEvent;


    /**
     * @var string
     *
     * @ORM\Column(name="Lieu", type="string", length=255)
     */
    private $lieuEvent;

    /**
     * @var string
     *
     * @ORM\Column(name="Description", type="string", length=255)
     */
    private $descEvent;

    /**
     * @var string
     *
     * @ORM\Column(name="Type", type="string", length=255)
     */
    private $typeEvent;

    /**
     * @var int
     *
     * @ORM\Column(name="NbrPart", type="integer")
     */
    private $nbrPartEvent;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="Date", type="datetime")
     */
    private $dateEvent;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="DateFin", type="datetime")
     */
    private $dateFinEvent;

    /**
     * @var int
     *
     * @ORM\Column(name="CmpPart", type="integer")
     */
    private $cmpPartEvent=0;

    /**
     * @var string
     *
     * @ORM\Column(name="Image", type="string", length=255)
     */
    private $imageEvent;

    /**
     * Get idEvent
     *
     * @return int
     */

    public function getidEvent()
    {
        return $this->idEvent;
    }

    /**
     * Set titreEvent
     *
     * @param string $titreEvent
     *
     * @return Evenement
     */
    public function setTitreEvent($titreEvent)
    {
        $this->titreEvent = $titreEvent;

        return $this;
    }

    /**
     * Get titreEvent
     *
     * @return string
     */
    public function getTitreEvent()
    {
        return $this->titreEvent;
    }

    /**
     * Set orgaEvent
     *
     * @param string $orgaEvent
     *
     * @return Evenement
     */
    public function setOrgaEvent($orgaEvent)
    {
        $this->orgaEvent = $orgaEvent;

        return $this;
    }

    /**
     * Get orgaEvent
     *
     * @return string
     */
    public function getOrgaEvent()
    {
        return $this->orgaEvent;
    }

    /**
     * Set lieuEvent
     *
     * @param string $lieuEvent
     *
     * @return Evenement
     */
    public function setLieuEvent($lieuEvent)
    {
        $this->lieuEvent = $lieuEvent;

        return $this;
    }

    /**
     * Get lieuEvent
     *
     * @return string
     */
    public function getLieuEvent()
    {
        return $this->lieuEvent;
    }

    /**
     * Set descEvent
     *
     * @param string $descEvent
     *
     * @return Evenement
     */
    public function setDescEvent($descEvent)
    {
        $this->descEvent = $descEvent;

        return $this;
    }

    /**
     * Get descEvent
     *
     * @return string
     */
    public function getDescEvent()
    {
        return $this->descEvent;
    }

    /**
     * Set typeEvent
     *
     * @param string $typeEvent
     *
     * @return Evenement
     */
    public function setTypeEvent($typeEvent)
    {
        $this->typeEvent = $typeEvent;

        return $this;
    }

    /**
     * Get typeEvent
     *
     * @return string
     */
    public function getTypeEvent()
    {
        return $this->typeEvent;
    }

    /**
     * Set nbrPartEvent
     *
     * @param integer $nbrPartEvent
     *
     * @return Evenement
     */
    public function setNbrPartEvent($nbrPartEvent)
    {
        $this->nbrPartEvent = $nbrPartEvent;

        return $this;
    }

    /**
     * Get nbrPartEvent
     *
     * @return int
     */
    public function getNbrPartEvent()
    {
        return $this->nbrPartEvent;
    }

    /**
     * Set dateEvent
     *
     * @param \DateTime $dateEvent
     *
     * @return Evenement
     */
    public function setDateEvent($dateEvent)
    {
        $this->dateEvent = $dateEvent;

        return $this;
    }

    /**
     * Get dateEvent
     *
     * @return \DateTime
     */
    public function getDateEvent()
    {
        return $this->dateEvent;
    }

    /**
     * Set cmpPartEvent
     *
     * @param integer $cmpPartEvent
     *
     * @return Evenement
     */
    public function setCmpPartEvent($cmpPartEvent)
    {
        $this->cmpPartEvent = $cmpPartEvent;

        return $this;
    }

    /**
     * Get cmpPartEvent
     *
     * @return int
     */
    public function getCmpPartEvent()
    {
        return $this->cmpPartEvent;
    }

    /**
     * Get imageEvent
     *
     * @return string
     */
    public function getImageEvent()
    {
        return $this->imageEvent;
    }

    /**
     * Set imageEvent
     *
     * @param string $imageEvent
     *
     * @return Evenement
     */
    public function setImageEvent($imageEvent)
    {
        $this->imageEvent = $imageEvent;

        return $this;
    }

    /**
     * Get dateFinEvent
     *
     * @return \DateTime
     */
    public function getDateFinEvent()
    {
        return $this->dateFinEvent;
    }

    /**
     * Set dateFinEvent
     *
     * @param \DateTime $dateFinEvent
     *
     * @return Evenement
     */
    public function setDateFinEvent($dateFinEvent)
    {
        $this->dateFinEvent = $dateFinEvent;

        return $this;
    }
}

