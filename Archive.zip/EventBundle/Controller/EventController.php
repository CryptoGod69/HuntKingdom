<?php

namespace EventBundle\Controller;

use EventBundle\Entity\Evenement;
use EventBundle\Entity\Participation;
use EventBundle\Form\EvenementType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\Compiler\RepeatedPass;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints\Date;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\HttpFoundation\Response;
use CMEN\GoogleChartsBundle\GoogleCharts\Charts\PieChart;

class EventController extends Controller
{
    /**
     * @Route("/ajout")
     */
    public function ajoutAction(Request $request)
    {


        if($this->getUser() == null){
            return $this->redirectToRoute( "login_page" );
        }

        $event = new Evenement();
        $em = $this->getDoctrine()->getManager();
        $form = $this->createForm( EvenementType::class, $event);
        $form->handleRequest( $request );
        $user = $this->getUser();



        if ($form->isSubmitted()) {
            $event->setOrgaEvent($user);
            $file = $event->getImageEvent();
            $fileName = md5( uniqid() ) . '.' . $file->guessExtension();
            $file->move(
                $this->getParameter( 'image_directory' ), $fileName );
            $event->setImageEvent( $fileName );
          //  $event->setImageEvent( $fileName );
            $em->persist( $event );
            $em->flush();
            return $this->redirectToRoute( "afficher_page" );
        }

        return $this->render( "@Event/Event/ajout.html.twig", array('form' => $form->createView(),
        ) );
    }

    public function afficherAction()
    {
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository( "EventBundle:Evenement" )->findAll();
        return $this->render( "@Event/Event/afficher.html.twig", array('events' => $event) );
    }

    public function modifierAction(Request $request, Evenement $event)
    {
        $event = $this->getDoctrine()->getRepository( "EventBundle:Evenement" )->find( $event->getidEvent() );
        $Form = $this->createForm( EvenementType::class, $event );

        $Form->get( 'titreEvent' )->setData( $event->getTitreEvent(), TextType::class );
       // $Form->get( 'orgaEvent' )->setData( $event->getOrgaEvent(), TextType::class );
        $Form->get( 'lieuEvent' )->setData( $event->getLieuEvent(), TextType::class );
        $Form->get( 'descEvent' )->setData( $event->getDescEvent(), TextType::class );
        $Form->get( 'typeEvent' )->setData( $event->getTypeEvent(), TextField::class );
        $Form->get( 'nbrPartEvent' )->setData( $event->getNbrPartEvent(), TextField::class );
        $Form->get( 'dateEvent' )->setData( $event->getDateEvent(), DateType::class );
        $Form->get( 'dateFinEvent' )->setData( $event->getDateEvent(), DateType::class );


        $Form->handleRequest( $request );
        if ($Form->isSubmitted() && $Form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $event->setTitreEvent( $event->getTitreEvent() );
            $event->setOrgaEvent( $event->getOrgaEvent() );
            $event->setLieuEvent( $event->getLieuEvent() );
            $event->setDescEvent( $event->getDescEvent() );
            $event->setTypeEvent( $event->getTypeEvent() );
            $event->setNbrPartEvent( $event->getNbrPartEvent() );
            $event->setDateEvent( $event->getDateEvent() );
            $event->setCmpPartEvent( $event->getCmpPartEvent() );
            $em->flush();
            return $this->redirectToRoute( 'modifier_page', array('id' => $event->getidEvent()) );

        }
        return $this->render( '@Event/Event/modifier.html.twig', array('form' => $Form->createView()) );
    }

    public function SupprimerAction(Request $request, Evenement $event)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove( $event );
        $em->flush();
        return $this->redirectToRoute( "afficher_page" );

    }

    public function supprimerBackAction(Request $request, Evenement $event)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove( $event );
        $em->flush();
        return $this->redirectToRoute( "eventsBack_page" );

    }
    public function detailsAction(int $id)
    {
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository( "EventBundle:Evenement" )->find( $id );
        return $this->render( "@Event/Event/details.html.twig", array('events' => $event) );
    }
    public function participerAction(Request $request, int $id)
    {
        if($this->getUser() == null){
            return $this->redirectToRoute( "login_page" );
        }

        $em = $this->getDoctrine()->getManager();
        $part = new Participation();
        $user = $this->getUser()->getId();
        $username = $this->getUser();

$doctrine = $this->getDoctrine();
$repository = $doctrine->getRepository(Participation::class);
$event = $em->getRepository( Evenement::class )->find($id);

$participation = $repository->getParticipation($user,$id);
        $var=$event->getCmpPartEvent();
        $var2=$event->getNbrPartEvent();
        if (count( $participation) > 0) {
            return new Response( 'Already Participated ;)' );
        } else if ($var < $var2) {
            $part->setIdEvent($id);
            $part->setIdUser($user);
            $part->setPartEvent($username);
            $event->setCmpPartEvent($var+1);
            $em->persist( $part );
            $em->flush();
            return new Response( 'Participation Added ;)' );

        }else
        {
            return new Response( 'Complet sahby ;) ;)' );

        }
    }

    public function myeventsAction(Request $request)
    {
        if($this->getUser() == null){
            return $this->redirectToRoute( "login_page" );
        }

        $user=$this->getUser();//Akida
        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(Evenement::class);
        $event = $repository->getMyEvents("mourad");
        return $this->render( "@Event/Event/afficherMyEvents.html.twig", array('events' => $event) );
    }



    public function annulerAction(Request $request, int $id)
    {

        if($this->getUser() == null){
            return $this->redirectToRoute( "login_page" );
        }
        $em = $this->getDoctrine()->getManager();

        $user = $this->getUser()->getId();

        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(Participation::class);
        $participation = $repository->getParticipationId($user,$id);

        $event = $em->getRepository( Evenement::class )->find($id);
        $var=$event->getCmpPartEvent();

        if (count( $participation) > 0) {
            $event->setCmpPartEvent($var-1);

             $em->remove($participation[0]);
            $em->flush();
        } else {
            return new Response( 'You are not into this DUDE. ;)' );
        }
        return $this->redirectToRoute( "afficher_page" );
    }

    public function kickAction(Request $request, int $id,String $username)
    {
        $em = $this->getDoctrine()->getManager();
        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(Participation::class);
        $participation = $repository->getParticipation($username,$id);
        $event = $em->getRepository( Evenement::class )->find($id);
        $var=$event->getCmpPartEvent();

        if (count( $participation) > 0) {
            $event->setCmpPartEvent($var-1);
            $em->remove($participation[0]);
            $em->flush();
        } else {
            return new Response( 'You are not into this DUDE. ;)' );
        }
        return new Response( 'DONE ya man ;)' );

        //  return $this->redirectToRoute( "afficher_page" );
    }


    public function showEventPartsAction($id){
    $rep=$this->getDoctrine()->getRepository(Participation::class);
    $data=$rep->getEventParts($id);
    return $this->render( "@Event/Back/EventPartsBack.html.twig", array('data' => $data) );
    }

/*
    public function getGoingEventsAction()
    {

        $userid = $this->getUser()->getId();
        $em = $this->getDoctrine()->getManager();
        $repository = $this->getDoctrine()->getRepository( Participation::class );
        $repositoryEvent = $this->getDoctrine()->getRepository( Evenement::class );

        $parts = $repository->find( $userid );
        foreach ($parts as $part) {
            $eventsIDS = $part->getIdEvent();
            $events = $repositoryEvent->getGoingEvents($parts->getIdEvent());
            var_dump($events);
        }
        var_dump($events);

      //  var_dump($parts);
        return new Response('ok');

    }

/*
 *
       if(count($output) > 0){

           return $this->render( "@Event/Event/goingEvents.html.twig", array('parts' => $events) );
       }else
              return new Response('Ops !');

    }

*/









/* back stuff */

    public function showEventsBackAction()
    {

        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository( "EventBundle:Evenement" )->findAll();
        if($this->getUser()==null)
        {
            return $this->redirectToRoute('fos_user_security_login');
        }else{
            if(!in_array('ROLE_SUPER_ADMIN', $this->getUser()->getRoles())) {
                return $this->redirectToRoute('afficher_page'  );
            }}
            return $this->render( "@Event/Back/EventsBack.html.twig", array('events' => $event) );
    }



    public function chartAction()
    {
        $pieChart = new PieChart();
        $pieChart->getData()->setArrayToDataTable(
            [['Task', 'Hours per Day'],
                ['Chasse',     11],
                ['Formation',      2],
                ['Reunion',  2],

            ]
        );
        $pieChart->getOptions()->setTitle('Event Types');
        $pieChart->getOptions()->setHeight(500);
        $pieChart->getOptions()->setWidth(900);
        $pieChart->getOptions()->getTitleTextStyle()->setBold(true);
        $pieChart->getOptions()->getTitleTextStyle()->setColor('#009900');
        $pieChart->getOptions()->getTitleTextStyle()->setItalic(true);
        $pieChart->getOptions()->getTitleTextStyle()->setFontName('Arial');
        $pieChart->getOptions()->getTitleTextStyle()->setFontSize(20);

        return $this->render('@Event/Back/chartBack.html.twig', array('piechart' => $pieChart));
    }



/* redirections */


    public function accueilAction()
    {
        return $this->render( "@Event/Event/accueil.html.twig");
    }
    public function loginAction()
    {
        return $this->render( "@Event/Event/login.html.twig");
    }
    public function mapAction()
    {
        return $this->render( "@Event/Event/erreur.html.twig");
    }






}

