<?php

namespace EventBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('@Event/Default/index.html.twig');

    }

    public function indexingAction()
    {
        return $this->render('@Event/Default/indexing.html.twig');
    }

    public function indexinAction() {

        if($this->getUser()==null)
        {
            return $this->redirectToRoute('fos_user_security_login');
        }
        if(!in_array('ROLE_SUPER_ADMIN', $this->getUser()->getRoles())) {
            return $this->redirectToRoute('afficher_page'  );
        }
        return $this->redirectToRoute('eventsBack_page');
        return $this->render('@Event/Back/EventsBack.html.twig');

    }




}
