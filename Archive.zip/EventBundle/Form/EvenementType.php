<?php

namespace EventBundle\Form;

use EventBundle\Entity\Evenement;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
    use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class EvenementType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {



        $builder->add('titreEvent')
            ->add('typeEvent', ChoiceType::class, [
                 'choices' => [
                     'Chasse' => 'Chasse',
                     'Formation' => 'formation',
                     'Reunion' => 'Reunion',
                 ],
            ])
            ->add('descEvent')
            ->add('lieuEvent')
            ->add('nbrPartEvent')
            ->add('dateEvent',DateType::Class, array(
                'widget' => 'choice',
                'years' => range(date('Y'), date('Y')+100),
                'months' => range(date('m'), 12),
                'days' => range(date('d'), 31),
            ))
            ->add('dateFinEvent',DateType::Class, array(
                'widget' => 'choice',
                'years' => range(date('Y'), date('Y')+100),
                'months' => range(date('m'), 12),
                'days' => range(date('d'), 31),
            ))
            ->add('imageEvent',FileType::class,array('label'=>'Insert Image'))
            ->add('ajouter',SubmitType::class);


    }/**
 * {@inheritdoc}
 */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'EventBundle\Entity\Evenement'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'eventbundle_evenement';
    }


}
