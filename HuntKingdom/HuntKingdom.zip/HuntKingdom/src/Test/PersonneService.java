/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Models.Personne;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Utils.DataSource;

/**
 *
 * @author Omar
 */
public class PersonneService {
    
    Connection cnx = DataSource.getInstance().getCnx();
    
    public void ajouterPersonne(Personne p) throws SQLException{
        String requete = "insert into personnes (nom,prenom) values ('"+p.getNom()+"','"+p.getPrenom()+"')";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Ajout effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void ajouterPersonne2(Personne p) throws SQLException {
        String requete = "insert into personnes (nom,prenom) values ('"+p.getNom()+"','"+p.getPrenom()+"')";
        try {
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1,p.getNom());
            pst.setString(2, p.getPrenom());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<Personne> getListPersonne(){
        List<Personne> list = new ArrayList<>();
        String requete = "select * from personnes";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                Personne p = new Personne();
                p.setId(rs.getInt(1));
                p.setNom(rs.getString(2));
                p.setPrenom(rs.getString("prenom"));
                list.add(p);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
}
