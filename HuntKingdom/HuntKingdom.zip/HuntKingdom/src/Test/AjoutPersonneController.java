/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import Models.Personne;
import Services.PersonneService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class AjoutPersonneController implements Initializable {

    @FXML
    private TextField nom_field;
    @FXML
    private TextField prenom_field;
    @FXML
    private Button enregistrer_button;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void AjouterUnePersonne(ActionEvent event) throws SQLException, IOException {
        PersonneService ps = new PersonneService();
        Personne p = new Personne(nom_field.getText(), prenom_field.getText());
        ps.ajouterPersonne(p);
        
        JOptionPane.showMessageDialog(null, "Personne ajoutée !");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("DetailPersonne.fxml"));
        
        Parent root = loader.load();
        nom_field.getScene().setRoot(root);
        
        DetailPersonneController dpc = loader.getController();
        dpc.setNom_label(nom_field.getText());
        dpc.setPrenom_label(prenom_field.getText());
    }
    
}
