/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Topic;
import Models.User;
import Services.TopicService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class ShowTopicController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private TableView<Topic> topicList;
    @FXML
    private TableColumn<Topic, String> idColumn;
    @FXML
    private TableColumn<Topic, String> titleColumn;
    @FXML
    private TableColumn<Topic, String> authorColumn;
    @FXML
    private TableColumn<Topic, String> nbPostsColumn;
    @FXML
    private TableColumn<Topic, String> lastPostDateColumn;
    @FXML
    private Button deleteButton;
    @FXML
    private Button editButton;
    @FXML
    private Button showButton;

    protected static User user;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    

    @FXML
    private void Add(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddTopic.fxml"));
        Parent root = loader.load();
        topicList.getScene().setRoot(root);
        AddTopicController atc = loader.getController();
        atc.authorField.setText(user.getNomUser());
    }

    private void Load() {
        TopicService ts = new TopicService();
        ObservableList<Topic> tlist = ts.readTopicList();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        nbPostsColumn.setCellValueFactory(new PropertyValueFactory<>("nbPosts"));
        lastPostDateColumn.setCellValueFactory(new PropertyValueFactory<>("lastPostDate"));
        topicList.setItems(tlist);
    }

    @FXML
    private void Delete(ActionEvent event) {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            TopicService ts = new TopicService();
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ts.deleteTopic(t.getId());
            Load();
        }
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            Topic t = topicList.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditTopic.fxml"));
            Parent root = loader.load();
            topicList.getScene().setRoot(root);
            EditTopicController etc = loader.getController();
            etc.idField.setText(Integer.toString(t.getId()));
            etc.titleField.setText(t.getTitle());
            etc.authorField.setText(t.getAuthor());
            etc.nbPostsField.setText(Integer.toString(t.getNbPosts()));
            etc.lastPostDateField.setText(t.getLastPostDate().toString());
        }
    }

    @FXML
    private void Show(ActionEvent event) throws IOException {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ShowPostController.user = user;
            ShowPostController.topicId = t.getId();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
            Parent root = loader.load();
            topicList.getScene().setRoot(root);
            ShowPostController spc = loader.getController();
        }
    }
    
}
