/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Post;
import Models.Topic;
import Services.PostService;
import Services.TopicService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class AddTopicController implements Initializable {

    @FXML
    private TextField titleField;
    @FXML
    protected TextField authorField;
    @FXML
    private TextField messageField;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    /*
    public TextField getTitleField() {
        return titleField;
    }

    public TextField getAuthorField() {
        return authorField;
    }

    public TextField getMessageField() {
        return messageField;
    }
    */
    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        if(!titleField.getText().isEmpty() && !authorField.getText().isEmpty() && !messageField.getText().isEmpty()){
            TopicService ts = new TopicService();
            PostService ps = new PostService();
            Topic t = new Topic(titleField.getText(), authorField.getText());
            ts.createTopic(t);
            Post p = new Post(ts.getLastTopicId(), authorField.getText(), messageField.getText());
            ps.createPost(p);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
            Parent root = loader.load();
            titleField.getScene().setRoot(root);
        }
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
        Parent root = loader.load();
        titleField.getScene().setRoot(root);
    }
    
    
}
