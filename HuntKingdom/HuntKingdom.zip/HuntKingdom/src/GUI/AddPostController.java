/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Post;
import Services.PostService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class AddPostController implements Initializable {

    @FXML
    private TextField messageField;
    @FXML
    protected TextField authorField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    
    protected static int topicId;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        ShowPostController.topicId = topicId;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
        Parent root = loader.load();
        messageField.getScene().setRoot(root);
        ShowPostController spc = loader.getController();
    }

    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        if(!messageField.getText().isEmpty() && !authorField.getText().isEmpty()){
            PostService ps = new PostService();
            Post p = new Post(topicId, authorField.getText(), messageField.getText());
            ps.createPost(p);
            ShowPostController.topicId = topicId;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
            Parent root = loader.load();
            messageField.getScene().setRoot(root);
            ShowPostController spc = loader.getController(); 
        }
    }
    
}
