/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Post;
import Models.User;
import Services.PostService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class ShowPostController implements Initializable {
    
    @FXML
    private TableView<Post> postList;
    @FXML
    private TableColumn<Post, String> idColumn;
    @FXML
    private TableColumn<Post, String> authorColumn;
    @FXML
    private TableColumn<Post, String> dateColumn;
    @FXML
    private TableColumn<Post, String> messageColumn;
    @FXML
    private Button addButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button editButton;
    @FXML
    private Button returnButton;
    
    protected static int topicId;
    protected static User user;
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    

    @FXML
    private void Add(ActionEvent event) throws IOException {
        AddPostController.topicId = topicId;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddPost.fxml"));
        Parent root = loader.load();
        postList.getScene().setRoot(root);
        AddPostController apc = loader.getController();
        apc.authorField.setText(user.getNomUser());
    }
    
    private void Load() {
        PostService ps = new PostService();
        ObservableList<Post> plist = ps.readPostTopic(topicId);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        messageColumn.setCellValueFactory(new PropertyValueFactory<>("message"));
        postList.setItems(plist);
    }

    @FXML
    private void Delete(ActionEvent event) {
        if(postList.getSelectionModel().getSelectedItem() != null){
            PostService ps = new PostService();
            Post p = postList.getSelectionModel().getSelectedItem();
            ps.deletePost(p.getId());
            Load();
        }
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
        if(postList.getSelectionModel().getSelectedItem() != null){
            Post p = postList.getSelectionModel().getSelectedItem();
            EditPostController.topicId = p.getTopicId();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditPost.fxml"));
            Parent root = loader.load();
            postList.getScene().setRoot(root);
            EditPostController epc = loader.getController();
            epc.idField.setText(Integer.toString(p.getId()));
            epc.authorField.setText(p.getAuthor());
            epc.dateField.setText(p.getDate().toString());
            epc.messageField.setText(p.getMessage());
        }
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
        Parent root = loader.load();
        postList.getScene().setRoot(root);
    }
    
}
