/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Services.UserService;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Omar
 */
public class PostListCell extends ListCell<Post>{
    private final GridPane gridPane = new GridPane(); 
    private final Label messageLabel = new Label(); 
    private final Label authorLabel = new Label();
    private final Label dateLabel = new Label();
    private final ImageView authorIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public PostListCell() { 
        authorIcon.setFitWidth(45); 
        authorIcon.setPreserveRatio(true); 
        GridPane.setConstraints(authorIcon, 0, 0, 1, 3); 
        GridPane.setValignment(authorIcon, VPos.TOP); 
        // 
        messageLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(messageLabel, 1, 0); 
        // 
        dateLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(dateLabel, 2, 0); 
        //
        authorLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(authorLabel, 1, 1); 
        //                 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(authorIcon, messageLabel, dateLabel, authorLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override 
    protected void updateItem(Post item, boolean empty) { 
        super.updateItem(item, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && item != null) { 
            messageLabel.setText(item.getMessage()); 
            authorLabel.setText(item.getAuthor()); 
            dateLabel.setText(item.getDate().toString());
            //
            UserService us = new UserService();
            User u = new User();
            u = us.showName(item.getAuthor());
            String path = "/Resources/users/0.png";
            
            File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/users/"+u.getId()+".jpg");
            if(tmp.exists()){
                path = "/Resources/users/"+u.getId()+".jpg";
            }
            
            Image image = new Image(getClass().getResource(path).toExternalForm());
            authorIcon.setImage(image);
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}
