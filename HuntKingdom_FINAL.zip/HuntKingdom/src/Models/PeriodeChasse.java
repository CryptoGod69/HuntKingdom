/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.time.LocalDate;

/**
 *
 * @author Legion
 */
public class PeriodeChasse {
    private int IdP;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private String adresse;
    private int superficie;

    public PeriodeChasse(LocalDate dateDebut, LocalDate dateFin, String adresse, int superficie) {
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.adresse = adresse;
        this.superficie = superficie;
    }

    public PeriodeChasse() {
    }

    public int getIdP() {
        return IdP;
    }

    public LocalDate getDateDebut() {
        return dateDebut;
    }

    public LocalDate getDateFin() {
        return dateFin;
    }

    public String getAdresse() {
        return adresse;
    }

    public int getSuperficie() {
        return superficie;
    }

    public void setIdP(int IdP) {
        this.IdP = IdP;
    }

    public void setDateDebut(LocalDate dateDebut) {
        this.dateDebut = dateDebut;
    }

    public void setDateFin(LocalDate dateFin) {
        this.dateFin = dateFin;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setSuperficie(int superficie) {
        this.superficie = superficie;
    }

    @Override
    public String toString() {
        return "PeriodeChasse{" + "IdP=" + IdP + ", dateDebut=" + dateDebut + ", dateFin=" + dateFin + ", adresse=" + adresse + ", superficie=" + superficie + '}';
    }
    
}
