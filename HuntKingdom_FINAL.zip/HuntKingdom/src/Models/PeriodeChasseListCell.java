/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.io.File;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Legion
 */
public class PeriodeChasseListCell extends ListCell<PeriodeChasse> {
    private final GridPane gridPane = new GridPane(); 
    private final Label dateDebutLabel = new Label(); 
    private final Label dateFinLabel = new Label();
    private final Label adresseLabel = new Label();
    private final Label superficieLabel = new Label();
    private final ImageView periodeIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public PeriodeChasseListCell() { 
        periodeIcon.setFitWidth(45); 
        periodeIcon.setPreserveRatio(true); 
        GridPane.setConstraints(periodeIcon, 0, 0, 1, 3); 
        GridPane.setValignment(periodeIcon, VPos.TOP); 
        // 
        dateDebutLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(dateDebutLabel, 1, 0); 
        //
        dateFinLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(dateFinLabel, 1, 1);
        // 
        adresseLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(adresseLabel, 2, 0); 
        // 
        superficieLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(superficieLabel, 2, 1); 
        //    
        
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true));
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(periodeIcon, dateDebutLabel, dateFinLabel, adresseLabel, superficieLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override
    protected void updateItem(PeriodeChasse item, boolean empty) { 
        super.updateItem(item, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && item != null) { 
            dateDebutLabel.setText(item.getDateDebut().toString()); 
            dateFinLabel.setText(item.getDateFin().toString()); 
            adresseLabel.setText(item.getAdresse()); 
            superficieLabel.setText(Integer.toString(item.getSuperficie())); 
            String path = "/Resources/produitNeuf/0.png";
            File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/periodes/"+item.getIdP()+".jpg");
            if(tmp.exists()){
                path = "/Resources/periodes/"+item.getIdP()+".jpg";
            }
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
               periodeIcon.setImage(image);
            }
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}
