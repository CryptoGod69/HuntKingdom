/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Models.Article;
import java.io.File;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Legion
 */
public class ArticleListCell extends ListCell<Article> {
    private final GridPane gridPane = new GridPane(); 
    private final Label titreLabel = new Label(); 
    private final Label sousTitreLabel = new Label();
    private final Label nbLikesLabel = new Label();
    private final Label categorieLabel = new Label();
    private final ImageView articleIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public ArticleListCell() { 
        articleIcon.setFitWidth(45); 
        articleIcon.setPreserveRatio(true); 
        GridPane.setConstraints(articleIcon, 0, 0, 1, 3); 
        GridPane.setValignment(articleIcon, VPos.TOP); 
        // 
        titreLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(titreLabel, 1, 0); 
        // 
        categorieLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(categorieLabel, 2, 1); 
        //
        nbLikesLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(nbLikesLabel, 2, 0); 
        //
        sousTitreLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(sousTitreLabel, 1, 1); 
        //                 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(articleIcon, titreLabel, sousTitreLabel, nbLikesLabel, categorieLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override
    protected void updateItem(Article item, boolean empty) { 
        super.updateItem(item, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && item != null) { 
            titreLabel.setText(item.getTitre()); 
            sousTitreLabel.setText(item.getSousTitre()); 
            categorieLabel.setText(item.getCategorie()); 
            nbLikesLabel.setText(Integer.toString(item.getNbLikes())+" Likes"); 
            String path = "/Resources/articles/0.png";
            File tmp = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/articles/"+item.getIdA()+".jpg");
            if(tmp.exists()){
                path = "/Resources/articles/"+item.getIdA()+".jpg";
            }
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
               articleIcon.setImage(image);
            }
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}
