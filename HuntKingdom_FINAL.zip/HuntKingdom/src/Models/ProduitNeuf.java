/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import javafx.scene.image.Image;


public class ProduitNeuf {
        private int reference;
        String nom;
        private String categorie;
        private String description;
        private float prix;
        private int nbProduits;
        private int idProdNeuf;
        
        public ProduitNeuf(int reference, String nom, String categorie, String description, float prix, int nbProduits, int idProdNeuf) {
        this.reference = reference;
        this.nom = nom;
        this.categorie = categorie;
        this.description = description;
        this.prix = prix;
        this.nbProduits = nbProduits;
        this.idProdNeuf=idProdNeuf;
    }
        
    public ProduitNeuf() {
        this.reference = 0;
        this.nom = "";
        this.categorie = "";
        this.description = "";
        this.prix = 0;
        this.nbProduits = 0;
        idProdNeuf=0;
    }
        
        public int getIdProdNeuf() {
        return idProdNeuf;
    }

    public void setIdProdNeuf (int idProdNeuf) {
        this.idProdNeuf= idProdNeuf;
    }  
    
    public int getReference() {
        return reference;
    }

    public void setReference(int reference) {
        this.reference= reference;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

      
    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix= prix;
    }
    
   
    public int getNbProduits() {
        return nbProduits;
    }

    public void setNbProduits(int nbProduit) {
        this.nbProduits= nbProduit;
    }

    @Override
    public String toString() {
        return "ProduitNeuf{" + "reference=" + reference + ", nom=" + nom + ", categorie=" + categorie + ", description=" + description + ", prix=" + prix + ", nbProduits=" + nbProduits + ", idProdNeuf=" + idProdNeuf + '}';
    }
}
