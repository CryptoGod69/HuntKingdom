/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.PeriodeChasse;
import Models.PeriodeChasseListCell;
import Services.PeriodeChasseService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class ShowPeriodeChasseUserController implements Initializable {

    @FXML
    private ListView<PeriodeChasse> PeriodeChasseList;
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Button articleButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Button returnButton;
  

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    
    private void Load() {
        for(int i=0; i<PeriodeChasseList.getItems().size(); i++){
            PeriodeChasseList.getItems().clear();
        }
        PeriodeChasseService pcs = new PeriodeChasseService();
        ObservableList<PeriodeChasse> plist =pcs.getListPeriodeChasse();
        PeriodeChasseList.setItems(plist);
        PeriodeChasseList.setCellFactory(new Callback<ListView<PeriodeChasse>, ListCell<PeriodeChasse>>() { 
            @Override 
            public ListCell<PeriodeChasse> call(ListView<PeriodeChasse> lv) { 
                return new PeriodeChasseListCell(); 
            } 
        });
     }
    @FXML
    private void search(ActionEvent event) {
        for(int i=0; i<PeriodeChasseList.getItems().size(); i++){
            PeriodeChasseList.getItems().clear();
        }
        PeriodeChasseService pcs = new PeriodeChasseService();
        ObservableList<PeriodeChasse> plist =pcs.rechercherPeriodeChasseAdresse(searchField.getText());
        PeriodeChasseList.setItems(plist);
        PeriodeChasseList.setCellFactory(new Callback<ListView<PeriodeChasse>, ListCell<PeriodeChasse>>() { 
            @Override 
            public ListCell<PeriodeChasse> call(ListView<PeriodeChasse> lv) { 
                return new PeriodeChasseListCell(); 
            } 
        });
    }

    @FXML
    private void GoArticle(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticleUser.fxml"));
        Parent root = loader.load();
        PeriodeChasseList.getScene().setRoot(root);
    }

    @FXML
    private void Cancel(ActionEvent event) {
        Load();
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        PeriodeChasseList.getScene().setRoot(root);
    }
    
}
