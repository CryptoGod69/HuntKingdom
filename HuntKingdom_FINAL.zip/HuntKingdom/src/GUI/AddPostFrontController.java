/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.AddPostController.topicId;
import Models.Post;
import Services.PostService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class AddPostFrontController implements Initializable {

    @FXML
    private TextField messageField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    @FXML
    protected TextField authorField;

    protected static int topicId;
    
    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.GREEN)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("READ HUNTING LAWS")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SPRAY)
                                 .postEffect(Content.PostEffect.STOP)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        ShowPostFrontController.topicId = topicId;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPostFront.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        messageField.getScene().setRoot(root);
        ShowPostFrontController spc = loader.getController();
    }

    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        if(!messageField.getText().isEmpty() && !authorField.getText().isEmpty()){
            PostService ps = new PostService();
            Post p = new Post(topicId, authorField.getText(), messageField.getText());
            ps.createPost(p);
            ShowPostFrontController.topicId = topicId;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("The post was added successfully");
            alert.showAndWait();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPostFront.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            messageField.getScene().setRoot(root);
            ShowPostFrontController spc = loader.getController(); 
        }
    }
    
}
