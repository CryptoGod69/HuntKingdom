/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Article;
import Models.ArticleListCell;
import Services.ArticleService;
import com.sun.istack.internal.logging.Logger;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class ShowArticleController implements Initializable {

    @FXML
    private ListView<Article> articleList;
    @FXML
    private Button addButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Button periodeChasseButton;
    @FXML
    private Button readButton;
    ObservableList<Article> aalist;
    private Article articleTest;
    @FXML
    private Button staticButton;
    @FXML
    private Button returnButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
        
        
    }   
    
    private void Load() {
        for(int i=0; i<articleList.getItems().size(); i++){
            articleList.getItems().clear();
        }
        ArticleService as = new ArticleService();
        ObservableList<Article> alist =as.getListArticle();
        articleList.setItems(alist);
        articleList.setCellFactory(new Callback<ListView<Article>, ListCell<Article>>() { 
            @Override 
            public ListCell<Article> call(ListView<Article> lv) { 
                return new ArticleListCell(); 
            }
            
        });
       aalist=alist;
       if (alist.size()>0){
           articleTest=alist.get(alist.size()-1);
       }
        
        
     }

    @FXML
    private void add(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddArticle.fxml"));
        Parent root = loader.load();
        articleList.getScene().setRoot(root);
        AddArticleController aac = loader.getController();
        if (aalist.size()>0){
            aac.lastIdArticle=articleTest.getIdA();
        }
        
    }
     
     
    @FXML
    private void edit(ActionEvent event) throws IOException {
        if(articleList.getSelectionModel().getSelectedItem() != null){
            Article a = articleList.getSelectionModel().getSelectedItem();
            EditArticleController.idA = a.getIdA();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditArticle.fxml"));
            Parent root = loader.load();
            articleList.getScene().setRoot(root);
            EditArticleController eac = loader.getController();
            eac.categorieBox.setValue(a.getCategorie().toString());
            eac.titreField.setText(a.getTitre());
            eac.sousTitreField.setText(a.getSousTitre());
            eac.chapeauField.setText(a.getChapeau());
            eac.texteArea.setText(a.getTexte());
        }
    }

    @FXML
    private void delete(ActionEvent event) throws SQLException {
        if(articleList.getSelectionModel().getSelectedItem() != null){
            ArticleService as = new ArticleService();
            Article a = articleList.getSelectionModel().getSelectedItem();
            as.supprimerArticle(a.getIdA());
            Load();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("The article was deleted successfully");
            alert.showAndWait();
        }
    }

    @FXML
    private void search(ActionEvent event) {
        for(int i=0; i<articleList.getItems().size(); i++){
            articleList.getItems().clear();
        }
        ArticleService as = new ArticleService();
        ObservableList<Article> alist =as.rechercherArticleCategorie(searchField.getText());
        articleList.setItems(alist);
        articleList.setCellFactory(new Callback<ListView<Article>, ListCell<Article>>() { 
            @Override 
            public ListCell<Article> call(ListView<Article> lv) { 
                return new ArticleListCell(); 
            } 
        });
        
    }

    @FXML
    private void GoPeriodeChasse(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
        Parent root = loader.load();
        articleList.getScene().setRoot(root);
    }

    @FXML
    private void Read(ActionEvent event) throws IOException {
        if(articleList.getSelectionModel().getSelectedItem() != null){
            Article a = articleList.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ReadArticle.fxml"));
            Parent root = loader.load();
            articleList.getScene().setRoot(root);
            ReadArticleController rac = loader.getController();
            rac.categorieLabel.setText(a.getCategorie());
            rac.titreLabel.setText(a.getTitre());
            rac.sousTitreLabel.setText(a.getSousTitre());
            rac.chapeauLabel.setText(a.getChapeau());
            rac.texteLabel.setText(a.getTexte());
            String path = "";
            path = "/Ressources/articles/"+a.getIdA()+".jpg";
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
                rac.articleView.setImage(image);
            }
            }
        }

    @FXML
    private void cancel(ActionEvent event) {
        Load();
    }

    @FXML
    private void GoStatic(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("Statistique.fxml"));
        Parent root = loader.load();
        articleList.getScene().setRoot(root);
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        articleList.getScene().setRoot(root);
    }
    }
    

