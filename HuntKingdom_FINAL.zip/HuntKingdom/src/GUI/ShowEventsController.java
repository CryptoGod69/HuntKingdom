/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Models.EvenementListCell;
import Models.User;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.controlsfx.control.Notifications;
import static sun.font.FontManagerNativeLibrary.load;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowEventsController implements Initializable {
    protected static User user;
    @FXML
    private Button showButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private ListView<Evenement> EventList;
    @FXML
    private Button feedButton;
    @FXML
    private Button joinButton;
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Button returnButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowEventsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }     
       private void Load() throws SQLException {
        for(int i=0; i<EventList.getItems().size(); i++){
            EventList.getItems().clear();
        }
        EvenementService es = new EvenementService();
        ObservableList<Evenement> elist = es.showEventList();
        EventList.setItems(elist);
          
        EventList.setCellFactory(new Callback<ListView<Evenement>, ListCell<Evenement>>() { 
            @Override 
            public ListCell<Evenement> call(ListView<Evenement> lv) { 
                return new EvenementListCell(); 
            } 
        });      
    }
    @FXML
    private void Add(ActionEvent event) throws IOException {
        AddEventController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddEvent.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
        AddEventController aec = loader.getController();
        aec.orgaField.setText(user.getFirstName()+" "+user.getLastName());
    }
    @FXML
    private void Edit(ActionEvent event) throws IOException {  
        if(EventList.getSelectionModel().getSelectedItem() == null){
            ErrorNotification();
        }else{   
            SuccesNotification();
        EvenementService es = new EvenementService();
        Evenement e = EventList.getSelectionModel().getSelectedItem();
        EditEventController.id = e.getIdEvent();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditEvent.fxml"));
        Parent root = loader.load();        
        EventList.getScene().setRoot(root);
        EditEventController etc = loader.getController();
        etc.titleField.setText(e.getTitre());
        etc.orgaField.setText(e.getOrganisateur());
        etc.lieuField.setText(e.getLieu());
        etc.descField.setText(e.getDescription());
        etc.partsField.setText(Integer.toString(e.getNbrPart()));
        etc.dateField.setValue(e.getDate()); 
        }
    }
    @FXML
    private void Delete(ActionEvent event) throws SQLException { 
        if(EventList.getSelectionModel().getSelectedItem() == null){
            ErrorNotification();
        }else{   
            SuccesNotification();
        EvenementService es = new EvenementService();
        Evenement e = EventList.getSelectionModel().getSelectedItem();
        es.removeEvent(e.getIdEvent());
        Load();
        }
    }
    @FXML
    private void goFeed(ActionEvent event) throws IOException {
        ShowFeedPubController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPub.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
        
    }
    @FXML
    private void joinEvent(ActionEvent event) throws SQLException {
       
        if(EventList.getSelectionModel().getSelectedItem() == null){
        ErrorNotification();
        }else{
            SuccesNotification();
            EvenementService es = new EvenementService();
            Evenement e = EventList.getSelectionModel().getSelectedItem();
            es.Participer(e.getIdEvent(), user.getId());
            Load();
        }
    }
    
    private void SuccesNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Success :)")
                .text("Operation Succeeded")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
                      
        notificationBuilder.showConfirm();  
    }
    private void ErrorNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Fail :(")
                .text("Operation Failed")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
        notificationBuilder.showError();       
    }

    @FXML
    private void Search(ActionEvent event) throws SQLException {
        for(int i=0; i<EventList.getItems().size(); i++){
            EventList.getItems().clear();
        }
        EvenementService es = new EvenementService();
        ObservableList<Evenement> elist = es.showOneEvent(searchField.getText());
        EventList.setItems(elist);
          
        EventList.setCellFactory(new Callback<ListView<Evenement>, ListCell<Evenement>>() { 
            @Override 
            public ListCell<Evenement> call(ListView<Evenement> lv) { 
                return new EvenementListCell(); 
            } 
        });  
    }

    @FXML
    private void cancel(ActionEvent event) throws SQLException {
       
        for(int i=0; i<EventList.getItems().size(); i++){
            EventList.getItems().clear();
        }
        EvenementService es = new EvenementService();
        ObservableList<Evenement> elist = es.showEventList();
        EventList.setItems(elist);
          
        EventList.setCellFactory(new Callback<ListView<Evenement>, ListCell<Evenement>>() { 
            @Override 
            public ListCell<Evenement> call(ListView<Evenement> lv) { 
                return new EvenementListCell(); 
            } 
        });      
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeAdmin.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
    }
}
