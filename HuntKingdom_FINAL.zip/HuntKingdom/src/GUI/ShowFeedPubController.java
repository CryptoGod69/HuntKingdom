/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Models.EvenementListCell;
import Models.Feed;
import Models.FeedListCell;
import Models.User;
import Services.EvenementService;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowFeedPubController implements Initializable {
    protected static User user;
    @FXML
    private Button addButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button eventButton;
    @FXML
    private ListView<Feed> FeedList;
    @FXML
    private TextField searchField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button searchButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowFeedPubController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

 private void Load() throws SQLException {
         for(int i=0; i<FeedList.getItems().size(); i++){
            FeedList.getItems().clear();
        }
        FeedService fs = new FeedService();
        ObservableList<Feed> flist = fs.showPubList();
        FeedList.setItems(flist);
        FeedList.setCellFactory(new Callback<ListView<Feed>, ListCell<Feed>>() { 
            @Override 
            public ListCell<Feed> call(ListView<Feed> lv) { 
                return new FeedListCell(); 
            } 
        });
        
    }
    @FXML
    private void add(ActionEvent event) throws IOException {
        AddFeedPubController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddFeedPub.fxml"));
        Parent root = loader.load();
        FeedList.getScene().setRoot(root);

    
    }

    @FXML
    private void edit(ActionEvent event) throws IOException {
        /*
        FeedService fs = new FeedService();
        Feed f = FeedList.getSelectionModel().getSelectedItem();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditFeedPub.fxml"));
        Parent root = loader.load();        
        FeedList.getScene().setRoot(root);
        EditFeedPubController efpc = loader.getController();
      //  efpc.idField.setText(Integer.toString(f.getIdPub() ));
        efpc.userField .setText(Integer.toString(f.getidClient() ));
        efpc.titreField.setText(f.getTitrePub());
        efpc.contField.setText(f.getContPub());
        */
        if(FeedList.getSelectionModel().getSelectedItem() == null){
            ErrorNotification();
             }else{
             SuccesNotification();
        FeedService es = new FeedService();
        Feed f = FeedList.getSelectionModel().getSelectedItem();
        EditFeedPubController.id = f.getIdPub();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditFeedPub.fxml"));
        Parent root = loader.load();        
        FeedList.getScene().setRoot(root);
        EditFeedPubController efc = loader.getController();
        efc.titreField.setText(f.getTitrePub());
        efc.contField.setText(f.getContPub());
    
    }}
    @FXML
    private void delete(ActionEvent event) throws SQLException {
        if(FeedList.getSelectionModel().getSelectedItem() == null){
        ErrorNotification();
         }else{
        SuccesNotification();
        FeedService fs = new FeedService();
        Feed f = FeedList.getSelectionModel().getSelectedItem();
        fs.removePub(f.getIdPub());
        Load(); 
        }
}
    @FXML
    private void goEvent(ActionEvent event) throws IOException {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        FeedList.getScene().setRoot(root);
    }

    private void SuccesNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Success :)")
                .text("Operation Succeeded")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
                      
        notificationBuilder.showConfirm();  
    }
    private void ErrorNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Fail :(")
                .text("Operation Failed")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
        notificationBuilder.showError();       
    }

    @FXML
    private void Search(ActionEvent event) throws SQLException {
        for(int i=0; i<FeedList.getItems().size(); i++){
            FeedList.getItems().clear();
        }
        FeedService fs = new FeedService();
        ObservableList<Feed> flist = fs.showOnePub(searchField.getText());
        FeedList.setItems(flist);
          
        FeedList.setCellFactory(new Callback<ListView<Feed>, ListCell<Feed>>() { 
            @Override 
            public ListCell<Feed> call(ListView<Feed> lv) { 
                return new FeedListCell(); 
            } 
        });  
    }

    @FXML
    private void cancel(ActionEvent event) throws SQLException {
          for(int i=0; i<FeedList.getItems().size(); i++){
            FeedList.getItems().clear();
        }
        FeedService fs = new FeedService();
        ObservableList<Feed> flist = fs.showPubList();
        FeedList.setItems(flist);
          
        FeedList.setCellFactory(new Callback<ListView<Feed>, ListCell<Feed>>() { 
            @Override 
            public ListCell<Feed> call(ListView<Feed> lv) { 
                return new FeedListCell(); 
            } 
        }); 
    }
}
