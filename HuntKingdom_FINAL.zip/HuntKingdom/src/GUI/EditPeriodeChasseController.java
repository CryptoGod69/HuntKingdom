/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.EditArticleController.idA;
import Services.ArticleService;
import Services.PeriodeChasseService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class EditPeriodeChasseController implements Initializable {

    @FXML
    protected DatePicker dateDebutPicker;
    @FXML
    protected DatePicker dateFinPicker;
    @FXML
    protected TextField adresseField;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButtton;
    protected static int idP;
    @FXML
    protected TextField superficieField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Save(ActionEvent event) throws IOException {
        PeriodeChasseService pcs = new PeriodeChasseService();
        pcs.modifierPeriodeChasse(idP, dateDebutPicker.getValue(), dateFinPicker.getValue(), adresseField.getText(), Integer.parseInt(superficieField.getText()));
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
        Parent root = loader.load();
        adresseField.getScene().setRoot(root);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setContentText("The article was edited successfully");
        alert.showAndWait();
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
        Parent root = loader.load();
        adresseField.getScene().setRoot(root);
    }
    
}
