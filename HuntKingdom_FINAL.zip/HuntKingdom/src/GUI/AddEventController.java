/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Models.User;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.ResourceBundle;
import static java.util.concurrent.TimeUnit.DAYS;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class AddEventController implements Initializable {
    protected static User user;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    @FXML
    protected TextField orgaField;
    @FXML
    private TextField descField;
    @FXML
    private TextField titleField;
    @FXML
    private TextField lieuField;
    private TextField typeField;
    @FXML
    private TextField partsField;
   /*
    @FXML
    private TextField dateField;
   */
    @FXML 
    private ComboBox typeComboBox;
    @FXML
    private DatePicker dateField;
    
    ObservableList<String> typeList = FXCollections.observableArrayList("Chasse","Formation","Reunion");
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       typeComboBox.setValue("Chasse");
       typeComboBox.setItems(typeList);
    }   
    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        orgaField.getScene().setRoot(root);       
    }  
@FXML
    private void SuccesNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Success :)")
                .text("Operation Succeeded")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
                      
        notificationBuilder.showConfirm();  
    }
    @FXML
    private void ErrorNotification() {
        Notifications notificationBuilder = Notifications.create()
        .title("Fail :(")
                .text("Operation Failed")
                .graphic(null)
                .hideAfter(javafx.util.Duration.seconds(5))
                .position(Pos.BOTTOM_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                   @Override
                            public void handle(ActionEvent event){
                    System.out.println("TEST");
                }
                        });
        notificationBuilder.showError();       
    }
    
    @FXML
    private void save(ActionEvent event) throws IOException, SQLException {
       /* if (!titleField.getText().isEmpty()  || !lieuField.getText().isEmpty() || !typeField.getText().isEmpty())  {
            ErrorNotification();
        }else{
            SuccesNotification();
        */
       
        
          EvenementService es = new EvenementService();
     
          Evenement e = new Evenement(titleField.getText() , orgaField.getText() ,lieuField.getText() ,descField.getText() ,typeComboBox.getValue().toString() ,Integer.parseInt(partsField.getText()),dateField.getValue());
            es.addEvent(e);
            System.out.println("OK");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
            Parent root = loader.load();
            orgaField.getScene().setRoot(root);
            ShowEventsController spc = loader.getController();
            SuccesNotification();          
    }   
}
//}
