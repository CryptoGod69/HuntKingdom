/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class ReadArticleController implements Initializable {

    @FXML
    protected Label titreLabel;
    @FXML
    protected Label sousTitreLabel;
    @FXML
    protected Label categorieLabel;
    @FXML
    private Button backButton;
    @FXML
    protected Label chapeauLabel;
    @FXML
    protected Label texteLabel;
    @FXML
    protected ImageView articleView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Back(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        titreLabel.getScene().setRoot(root);
    }
    
}
