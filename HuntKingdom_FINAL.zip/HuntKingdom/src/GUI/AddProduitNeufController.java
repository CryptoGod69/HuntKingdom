    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.ProduitNeuf;
import Services.ProduitNeufService;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * FXML Controller class
 *
 * @author kaisk
 */
public class AddProduitNeufController implements Initializable {

    ObservableList<String> categ = FXCollections.observableArrayList("Arme","Vetement","Munitions","Accesoires");
    
        
    @FXML
    private TextField nomText;
    @FXML
    private TextField prixText;
    @FXML
    private TextField qteText;
    @FXML
    private ChoiceBox ctgBox;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private TextArea descTextArea;
    @FXML
    private Button importButton;
    @FXML
    private ImageView imageV;
    private String s;
    protected static int lastId=0;
    private Image imgTest;

    /**
     * Initializes the controller class.
     * @param url
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ctgBox.setValue("Arme");
        ctgBox.setItems(categ);
        //imageV.setImage(imgTest);
    }    

    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        if(!nomText.getText().isEmpty()&& !prixText.getText().isEmpty()&& !qteText.getText().isEmpty()&& !descTextArea.getText().isEmpty()){
            ProduitNeufService pn = new ProduitNeufService(); 
            ProduitNeuf p = new ProduitNeuf(0, nomText.getText(),ctgBox.getValue().toString(),descTextArea.getText(),Float.parseFloat(prixText.getText()),Integer.parseInt(qteText.getText()),0);
            pn.ajouterProduitNeuf(p);          
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeuf.fxml"));
            Parent root = loader.load();
            nomText.getScene().setRoot(root);
        }
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeuf.fxml"));
        Parent root = loader.load();
        nomText.getScene().setRoot(root);
    }
    
   

    @FXML
    private void importButton(ActionEvent event) throws FileNotFoundException {
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/produitNeuf"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG", "*.jpg"),new FileChooser.ExtensionFilter("JPEG", "*.jpeg"));
        File selectedFile = fc.showSaveDialog(null);
        
        if (selectedFile != null){
            String path = "";
            path = selectedFile.getAbsolutePath();
            s=path;
            //Image image = new Image(getClass().getResource(path).toExternalForm()); 
            //image = imgTest;
            lastId++;
            File nouveau = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/produitNeuf/"+lastId+".jpg");
            selectedFile.renameTo(nouveau);  
        }
    }
    
}
