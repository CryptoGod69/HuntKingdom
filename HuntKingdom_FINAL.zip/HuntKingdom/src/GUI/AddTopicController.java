/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Post;
import Models.Topic;
import Services.PostService;
import Services.TopicService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class AddTopicController implements Initializable {

    @FXML
    private TextField titleField;
    @FXML
    protected TextField authorField;
    @FXML
    private TextField messageField;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;

    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("SPAM = BAN")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.BLINK)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void Save(ActionEvent event) throws SQLException, IOException {
        if(!titleField.getText().isEmpty() && !authorField.getText().isEmpty() && !messageField.getText().isEmpty()){
            TopicService ts = new TopicService();
            PostService ps = new PostService();
            Topic t = new Topic(titleField.getText(), authorField.getText());
            ts.createTopic(t);
            Post p = new Post(ts.getLastTopicId(), authorField.getText(), messageField.getText());
            ps.createPost(p);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("The topic was added successfully");
            alert.showAndWait();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            titleField.getScene().setRoot(root);
        }
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        titleField.getScene().setRoot(root);
    }
    
    
}
