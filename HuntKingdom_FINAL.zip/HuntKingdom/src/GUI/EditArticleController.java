/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Article;
import Services.ArticleService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class EditArticleController implements Initializable {

    protected TextField categorieField;
    @FXML
    protected TextField titreField;
    @FXML
    protected TextField sousTitreField;
    @FXML
    protected TextField chapeauField;
    @FXML
    protected TextArea texteArea;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    protected static int idA;
    @FXML
    protected ComboBox<String> categorieBox;
    
    ObservableList<String> categorieList = FXCollections.observableArrayList("foret","vol","montagne");

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        categorieBox.setItems(categorieList);
        
    }    

    @FXML
    private void Save(ActionEvent event) throws IOException {
        ArticleService as = new ArticleService();
        as.modifierArticle(idA, categorieBox.getValue().toString(), titreField.getText(), sousTitreField.getText(), chapeauField.getText(), texteArea.getText());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setContentText("The article was edited successfully");
        alert.showAndWait();
    }

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
    }
    
}
