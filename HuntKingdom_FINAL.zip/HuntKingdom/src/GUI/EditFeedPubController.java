/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class EditFeedPubController implements Initializable {

    @FXML
    protected TextField idField;
    @FXML
    protected TextField userField;
    @FXML
    protected TextField titreField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    @FXML
    protected TextField contField;
    
    protected static int id;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPub.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
    }
    @FXML
    private void save(ActionEvent event) throws IOException {
         FeedService fs = new FeedService();
        fs.updatePub(id,99,titreField.getText() , contField.getText());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPub.fxml"));
        Parent root = loader.load();
        contField.getScene().setRoot(root); 
    }   
}
