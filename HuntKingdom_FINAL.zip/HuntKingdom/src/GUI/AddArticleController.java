/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Article;
import Services.ArticleService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class AddArticleController implements Initializable {

    private TextField categorieField;
    @FXML
    private TextField titreField;
    @FXML
    private TextField sousTitreField;
    @FXML
    private TextField chapeauField;
    @FXML
    private TextArea texteArea;
    @FXML
    private Button cancelButton;
    @FXML
    private Button addButton;
    @FXML
    private ComboBox<String> categorieBox;
    
    ObservableList<String> categorieList = FXCollections.observableArrayList("foret","vol","montagne");
    @FXML
    private Button importButton;
    protected static int lastIdArticle=0;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        categorieBox.setItems(categorieList);
    }    
     public TextField getCategorieField() {
        return categorieField;
    }

    public TextField getTitreField() {
        return titreField;
    }

    public TextField getSousTitreField() {
        return sousTitreField;
    }

    public TextField getChapeauField() {
        return chapeauField;
    }

    public TextArea getTexteArea() {
        return texteArea;
    }
    
    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
    }

    @FXML
    private void Add(ActionEvent event) throws SQLException, IOException {
          if(!categorieBox.getValue().isEmpty() && !titreField.getText().isEmpty() && !sousTitreField.getText().isEmpty()&& !chapeauField.getText().isEmpty() && !texteArea.getText().isEmpty()){
            ArticleService as = new ArticleService();
            Article a = new Article(categorieBox.getValue(), titreField.getText() ,sousTitreField.getText(),chapeauField.getText(),texteArea.getText());
            as.ajouterArticle(a);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
            Parent root = loader.load();
            titreField.getScene().setRoot(root);
            //Alert alert = new Alert(Alert.AlertType.INFORMATION);
            //alert.setTitle("Done");
            //alert.setContentText("The article was addeed successfully");
            //alert.showAndWait();
            
        }
    }

    @FXML
    private void importPicture(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File ("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/articles"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG","*.jpg"));
        File selectedFile = fc.showSaveDialog(null);
        if (selectedFile != null){
            String path="";
            path=selectedFile.getAbsolutePath();
            //Image image = new Image(getClass().getResource(path).toExternalForm());
            lastIdArticle++;
            File nouveau = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/articles/"+lastIdArticle+".jpg");
            selectedFile.renameTo(nouveau);
            
        }
        
    }
}
