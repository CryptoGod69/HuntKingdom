/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Feed;
import Models.User;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class AddFeedPubFrontController implements Initializable {
    protected static User user;
    @FXML
    private TextField titreField;
    @FXML
    private TextField contField;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void save(ActionEvent event) throws SQLException, IOException {
        FeedService fs = new FeedService();
          Feed f = new Feed(user.getId(), titreField.getText(), contField.getText());
            fs.addPub(f);
            System.out.println("OK");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPubFront.fxml"));
            Parent root = loader.load();
            titreField.getScene().setRoot(root);
                        ShowFeedPubFrontController spc = loader.getController();

    }

    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPubFront.fxml"));
        Parent root = loader.load();
        titreField.getScene().setRoot(root);
    }
    
}
