/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Topic;
import Models.TopicListCell;
import Models.User;
import Services.TopicService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class ShowTopicFrontController implements Initializable {

    @FXML
    private ListView<Topic> topicList;
    @FXML
    private Button addButton;
    @FXML
    private Button showButton;

    protected static User user;
    
    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("DONT ASK STUPID QUESTIONS")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SCROLL_LEFT)
                                 .effect(Content.Effect.BLINK)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    @FXML
    private Button returnButton;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }    

    @FXML
    private void Add(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AddTopicFront.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        topicList.getScene().setRoot(root);
        AddTopicFrontController atc = loader.getController();
        atc.authorField.setText(user.getFirstName()+" "+user.getLastName());
    }

    private void Load() {
        for(int i=0; i<topicList.getItems().size(); i++) {
            topicList.getItems().clear();
        }
        TopicService ts = new TopicService();
        ObservableList<Topic> tlist = ts.readTopicList();
        topicList.setItems(tlist);
        topicList.setCellFactory(new Callback<ListView<Topic>, ListCell<Topic>>() { 
            @Override 
            public ListCell<Topic> call(ListView<Topic> lv) { 
                return new TopicListCell(); 
            } 
        });
    }

    @FXML
    private void Show(ActionEvent event) throws IOException {
        if(topicList.getSelectionModel().getSelectedItem() != null){
            Topic t = topicList.getSelectionModel().getSelectedItem();
            ShowPostFrontController.user = user;
            ShowPostFrontController.topicId = t.getId();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPostFront.fxml"));
            VBox root = new VBox();
            root.getChildren().add(panel);
            root.getChildren().add(loader.load());
            topicList.getScene().setRoot(root);
            ShowPostFrontController spc = loader.getController();
        }
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        topicList.getScene().setRoot(root);
    }
    
}