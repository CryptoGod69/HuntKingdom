/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Services.PostService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class EditPostController implements Initializable {

    @FXML
    protected TextField authorField;
    @FXML
    protected TextField messageField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    
    protected static int topicId;
    protected static int id;
    
    MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("FLASH NEWS: NOTHING SPECIAL")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SCROLL_LEFT)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        ShowPostController.topicId = topicId;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        messageField.getScene().setRoot(root);
        ShowPostController spc = loader.getController();
    }

    @FXML
    private void Save(ActionEvent event) throws IOException {
        PostService ps = new PostService();
        ps.updatePost(id, messageField.getText());
        ShowPostController.topicId = topicId;
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setContentText("The post was edited successfully");
        alert.showAndWait();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPost.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        messageField.getScene().setRoot(root);
        ShowPostController spc = loader.getController();
    }
    
}
