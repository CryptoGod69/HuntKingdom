/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Commande;
import Models.CommandeListCell;
import Models.User;
import Services.CommandeService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class MyOrdersController implements Initializable {
    protected static User user;
    @FXML
    private Button returnButton;
    @FXML
    private ListView<Commande> listCommande;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Load();
    }
    
    private void Load(){
        CommandeService cs = new CommandeService();
        ObservableList<Commande> clist = cs.afficherCommandeClient(user.getId());
        listCommande.setItems(clist);
        listCommande.setCellFactory(new Callback<ListView<Commande>, ListCell<Commande>>() { 
            @Override 
            public ListCell<Commande> call(ListView<Commande> lv) { 
                return new CommandeListCell();
            } 
        });
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        returnButton.getScene().setRoot(root);
    }
    
}
