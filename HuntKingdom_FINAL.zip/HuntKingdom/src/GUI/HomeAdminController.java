/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.HomeController.user;
import Models.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import jfxtras.labs.scene.control.gauge.Content;
import jfxtras.labs.scene.control.gauge.ContentBuilder;
import jfxtras.labs.scene.control.gauge.MatrixPanel;
import jfxtras.labs.scene.control.gauge.MatrixPanelBuilder;

/**
 * FXML Controller class
 *
 * @author Omar
 */
public class HomeAdminController implements Initializable {

    protected static User user;
    @FXML
    private Button forumButton;
    @FXML
    private Button blogButton;
    @FXML
    private Button shopNeufButton;
    @FXML
    private Button shopOccasionButton;
    @FXML
    private Button feedEventButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Label welcomeLabel;
    @FXML
    private Button usersButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        welcomeLabel.setText("Welcome "+user.getFirstName()+" "+user.getLastName()+" !");
    }

    @FXML
    private void Forum(ActionEvent event) throws IOException {
        MatrixPanel panel = 
            MatrixPanelBuilder.create()
                         .ledWidth(400)
                         .ledHeight(40)
                         .prefWidth(760.0)
                         .prefHeight(760.0)
                         .frameVisible(true)
                         .contents(new Content[] {
                             new ContentBuilder().create()
                                 .color(Content.MatrixColor.RED)
                                 .type(Content.Type.TEXT)
                                 .origin(0, 10)
                                 .area(0, 0, 400, 40)
                                 .txtContent("DONT ASK STUPID QUESTIONS")
                                 .font(Content.MatrixFont.FF_10x16)
                                 .fontGap(Content.Gap.DOUBLE)
                                 .align(Content.Align.CENTER)
                                 .effect(Content.Effect.SCROLL_LEFT)
                                 .effect(Content.Effect.BLINK)
                                 .postEffect(Content.PostEffect.REPEAT)
                                 .order(Content.RotationOrder.SINGLE)
                                 .build()
                         })
                         .build();
        ShowTopicController.user = user;
        FXMLLoader loader = new FXMLLoader();
        loader = new FXMLLoader(getClass().getResource("ShowTopic.fxml"));
        VBox root = new VBox();
        root.getChildren().add(panel);
        root.getChildren().add(loader.load());
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void Blog(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowArticle.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void ShopNeuf(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowProduitNeuf.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void ShopOccasion(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AllRendezvous.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void FeedEvent(ActionEvent event) throws IOException {
        ShowEventsController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void Logout(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }

    @FXML
    private void Users(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowUser.fxml"));
        Parent root = loader.load();
        logoutButton.getScene().setRoot(root);
    }
    
}
