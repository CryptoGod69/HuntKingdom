/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.AddArticleController.lastIdArticle;
import Models.Article;
import Models.PeriodeChasse;
import Services.ArticleService;
import Services.PeriodeChasseService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Legion
 */
public class AddPeriodeChasseController implements Initializable {

    @FXML
    private DatePicker dateDebutPicker;
    @FXML
    private DatePicker dateFinPicker;
    @FXML
    private TextField adresseField;
    @FXML
    private TextField superficieField;
    @FXML
    private Button addButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Button importP;
    protected static int lastIdPeriode=0;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dateDebutPicker.setValue(LocalDate.now());
        dateFinPicker.setValue(LocalDate.now());
    }    

    public DatePicker getDateDebutPicker() {
        return dateDebutPicker;
    }

    public DatePicker getDateFinPicker() {
        return dateFinPicker;
    }

    public TextField getAdresseField() {
        return adresseField;
    }

    public TextField getSuperficieField() {
        return superficieField;
    }
    
    @FXML
    private void Add(ActionEvent event) throws IOException, SQLException {
         if(!adresseField.getText().isEmpty()&& !superficieField.getText().isEmpty()){
            if (dateDebutPicker.getValue().isBefore(dateFinPicker.getValue())){
            PeriodeChasseService pcs = new PeriodeChasseService();
            PeriodeChasse pc = new PeriodeChasse(dateDebutPicker.getValue(), dateFinPicker.getValue() ,adresseField.getText(),Integer.parseInt(superficieField.getText()));
            pcs.ajouterPeriodeChasse(pc);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
            Parent root = loader.load();
            adresseField.getScene().setRoot(root);
            //Alert alert = new Alert(Alert.AlertType.INFORMATION);
            //alert.setTitle("Done");
            //alert.setContentText("The periode chasse was addeed successfully");
           // alert.showAndWait();
            }
            else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
            //Parent root = loader.load();
            //Alert alert = new Alert(Alert.AlertType.INFORMATION);
            //alert.setTitle("Not Done");
            //alert.setContentText("Date Debut > Date Fin ");
            //alert.showAndWait();
            }
            
        }
         
    }
    

    @FXML
    private void Cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowPeriodeChasse.fxml"));
        Parent root = loader.load();
        adresseField.getScene().setRoot(root);
    }

    @FXML
    private void importP(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File ("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/periodes"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG","*.jpg"));
        File selectedFile = fc.showSaveDialog(null);
        if (selectedFile != null){
            String path="";
            path=selectedFile.getAbsolutePath();
            //Image image = new Image(getClass().getResource(path).toExternalForm());
            lastIdPeriode++;
            File nouveau = new File("/Users/mac/NetBeansProjects/HuntKingdom/src/Resources/periodes/"+lastIdPeriode+".jpg");
            selectedFile.renameTo(nouveau);
            
        }
    }
    
}
