package GUI;


import java.util.Optional;

//import org.json.simple.parser.ParseException;

import Models.Weather;
import Models.WeatherManager;

import java.io.IOException;
import java.text.ParseException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;


public class WindowController {

    @FXML
    private Label cityNameLabel;

    @FXML
    private ImageView weatherGraph;

    @FXML
    private Label temperatureLabel;
    
    
    @FXML
    private Button showWeatherButton;
    
    @FXML
    private ToggleGroup search;
    
    @FXML
    private TextField zipCodeTF;
    
    private TextField prefixTF;
    
    @FXML
    private TextField cityTF;
    
    @FXML
    private RadioButton byZipCode;
    
    @FXML
    private RadioButton byCity;
    
    
    WeatherManager weatherManager;
    @FXML
    private Button returnButton;


    public WindowController(){
    		weatherManager = new WeatherManager();
    		
    }
    
	public void initialize() throws ParseException{
		showWeather(null);
		
		
	} 	
	 	@FXML
	 	void showWeather(MouseEvent event) {
	 		try {
	 		Weather weather;
	 		if(byZipCode.isSelected()) {
	 			weather = weatherManager.getWeather(prefixTF.getText(), zipCodeTF.getText());
	 			cityNameLabel.setText("Place With a Code "+zipCodeTF.getText());
	 		}
			else {
				cityNameLabel.setText(cityTF.getText());
				weather = weatherManager.getWeather(cityNameLabel.getText());
			}
	 		
			temperatureLabel.setText(String.valueOf(weather.getTemperature())+(char)176+"C");
			weatherGraph.setImage(new Image("http://openweathermap.org/img/w/"+ weather.getIcon() +".png"));
	 		}catch(Exception e) {
	 			//Alert alert = new Alert(AlertType.ERROR);
	 			//alert.setTitle("City not found");
	 		/*	if(byCity.isSelected()) alert.setHeaderText("Nie znaleziono miasta o podanej nazwie.");
	 			else alert.setHeaderText("Nie znaleziono miasta o podanym kodzie pocztowym.");
	 			alert.setContentText("Sprawdź czy poprawnie wprowadziles dane. ");
 */	 			
                              //  alert.showAndWait();
               

	 			resetWeather();
	 			
	 		}
	 	}
	 	
	 	void resetWeather() {
	 		cityTF.setText("Tunisia");
	 		prefixTF.setText("tn");
	 		zipCodeTF.setText("2080");
	 		showWeather(null);	
	 	}

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEventsFront.fxml"));
        Parent root = loader.load();
        cityNameLabel.getScene().setRoot(root);
    }

    
}
