/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.HomeController.user;
import Models.User;
import Services.UserService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ProfilUserController implements Initializable {
    @FXML
    protected Label nomLabel;
    @FXML
    protected Label prenomLabel;
    @FXML
    protected Label emailLabel;
    @FXML
    protected Label telLabel;
    @FXML
    protected Label ddnLabel;
    @FXML
    protected ImageView image;
    
    protected static User user;
    @FXML
    private Button returnButton;
    @FXML
    private Button editButton;
    @FXML
    private Button myOrdersButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        Parent root = loader.load();
        nomLabel.getScene().setRoot(root);
    }

    @FXML
    private void Edit(ActionEvent event) throws IOException {
        EditFrontController.id = user.getId();
        EditFrontController.role = user.getRole();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditFront.fxml"));
        Parent root = loader.load();
        nomLabel.getScene().setRoot(root);
        EditFrontController.user = user;
        EditFrontController efc = loader.getController();
        efc.nomText.setText(user.getLastName());
        efc.prenomText.setText(user.getFirstName());
        efc.mdpText.setText(user.getPassword());
        efc.emailText.setText(user.getEmail());
        efc.telText.setText(Integer.toString(user.getPhone()));
        efc.ddnText.setValue(user.getBirthDate());
    }

    @FXML
    private void MyOrders(ActionEvent event) throws IOException {
        MyOrdersController.user = user;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MyOrders.fxml"));
        Parent root = loader.load();
        nomLabel.getScene().setRoot(root);
    }
    
}
