/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;


import Models.User;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Utils.DataSource;
import java.sql.Date;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Mourad
 */
public class UserService {
    
    Connection cnx = DataSource.getInstance().getCnx(); 
    public void addUser(User u) throws SQLException{
       
        int insId=u.getId();
        String insLastName=u.getLastName(); 
        String insFirstName=u.getFirstName();
        String insPassword=u.getPassword();
        String insEmail=u.getEmail();
        int insPhone=u.getPhone();
        String insRole=u.getRole();
        Date insBirthDate=java.sql.Date.valueOf(u.getBirthDate());
        
        String requete = "INSERT into  users (id,lastName,firstName,password,email,phone,role,birthDate)values ('"+insId+"','"+insLastName+"','"+insFirstName+"','"+insPassword+"','"+insEmail+"','"+insPhone+"','"+insRole+"','"+insBirthDate+"')";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("User added successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
       public void removeUser(int id) throws SQLException{
                   
        String requete = "DELETE FROM users WHERE id="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("User deleted successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       
       public User showOneUser(int id){
       System.out.println(id);
       User u = new User();
           String requete = "SELECT * FROM users WHERE id="+id;    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      u.setLastName(rs.getString(2));
                      u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      u.setPhone(rs.getInt(6)); 
                      u.setRole(rs.getString(7));
                      u.setBirthDate(rs.getDate(8).toLocalDate()); 
                      System.out.println(id);
                      System.out.println(u);
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
       
    public User showEmail(String email){
       
       User u = new User();
           String requete = "SELECT * FROM users WHERE email='"+email+"'";
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      u.setLastName(rs.getString(2));
                      u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      u.setPhone(rs.getInt(6)); 
                      u.setRole(rs.getString(7));
                      u.setBirthDate(rs.getDate(8).toLocalDate()); 
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
     
    public User showName(String Name){
       String[] names = Name.split(" ");
       String firstName = names[0];
       String lastName = names[1];
       User u = new User();
        String requete = "SELECT * FROM users WHERE firstName='"+firstName+"' AND lastName='"+lastName+"'";
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      u.setId(rs.getInt(1));
                      u.setLastName(rs.getString(2));
                      u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      u.setPhone(rs.getInt(6)); 
                      u.setRole(rs.getString(7));
                      u.setBirthDate(rs.getDate(8).toLocalDate()); 
           }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return u;
    }
    /**
     *
     * @return
     * @throws SQLException
     */
    public ObservableList<User> showUsersList(){
       
        ObservableList<User> listUsers = FXCollections.observableArrayList(); 
        String requete = "SELECT * FROM users";    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      User u = new User();
                      u.setId(rs.getInt(1));
                      u.setLastName(rs.getString(2));
                      u.setFirstName(rs.getString(3));
                      u.setPassword(rs.getString(4));                                       
                      u.setEmail(rs.getString(5)); 
                      u.setPhone(rs.getInt(6)); 
                      u.setRole(rs.getString(7));
                      u.setBirthDate(rs.getDate(8).toLocalDate()); 
                      listUsers.add(u);                
          }                        
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return listUsers;
    }
 
    
 
   
   public void updateUser (int id,String lastName,String firstName,String password,String email,int phone,String role,LocalDate birthDate)
     {
             String requete="UPDATE users SET lastName='"+lastName+"',firstName='"+firstName+"',password='"+password+"',email='"+email+"',phone='"+phone+"',role='"+role+"',birthDate='"+java.sql.Date.valueOf(birthDate)+"'WHERE id="+id;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("User updated successfully");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

