/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;
import Models.Article;
import Utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
/**
 *
 * @author Legion
 */
public class ArticleService {
    Connection cnx = DataSource.getInstance().getCnx();
    
    public void ajouterArticle(Article a) throws SQLException{
        String requete = "insert into article (categorie,titre,sousTitre,chapeau,texte,nbLikes) values ('"+a.getCategorie()+"','"+a.getTitre()+"','"+a.getSousTitre()+"','"+a.getChapeau()+"','"+a.getTexte()+"','"+0+"')";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Ajout Article effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /*
    public void ajouterArticle2(Article a) throws SQLException {
        String requete = "insert into article (categorie,titre,sousTitre,chapeau,texte) values ('"+a.getCategorie()+"',"+a.getTitre()+"','"+a.getSousTitre()+"','"+a.getChapeau()+"','"+a.getTexte()+"')";
        try {
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1,a.getTitre());
            pst.setString(2,a.getSousTitre());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    */
    public ObservableList<Article> getListArticle(){
        ObservableList<Article> articleList = FXCollections.observableArrayList();
        String requete = "select * from article";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                Article a = new Article();
                a.setIdA(rs.getInt("idA"));
                a.setCategorie(rs.getString("categorie"));
                a.setTitre(rs.getString("titre"));
                a.setSousTitre(rs.getString("sousTitre"));
                a.setChapeau(rs.getString("chapeau"));
                a.setTexte(rs.getString("texte"));
                a.setNbLikes(rs.getInt("nbLikes"));
                articleList.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return articleList;
    }
    
    public ObservableList<Article> rechercherArticleCategorie(String categorie){
        ObservableList<Article> articleList = FXCollections.observableArrayList();
        String requete = "select * from article WHERE categorie="+(char)34+categorie+(char)34;
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                Article a = new Article();
                a.setIdA(rs.getInt("idA"));
                a.setCategorie(rs.getString("categorie"));
                a.setTitre(rs.getString("titre"));
                a.setSousTitre(rs.getString("sousTitre"));
                a.setChapeau(rs.getString("chapeau"));
                a.setTexte(rs.getString("texte"));
                a.setNbLikes(rs.getInt("nbLikes"));
                articleList.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return articleList;
    }
    public void supprimerArticle(int IdA) throws SQLException {
       String requete = "DELETE FROM article WHERE IdA="+IdA;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Article supprimé");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    public void modifierArticle (int IdA,String categorie,String titre,String sousTitre,String chapeau,String texte){
             String requete="UPDATE article SET categorie='"+categorie+"',titre='"+titre+"',sousTitre='"+sousTitre+"',chapeau='"+chapeau+"',texte='"+texte+"' WHERE IdA="+IdA;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Article bien modifié");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     public Article rechercherArticle(String categorie){
          Article a = new Article();
        String requete = "select * from article WHERE categorie="+categorie;
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            
            while(rs.next()) {
                a.setIdA(rs.getInt(1));
                a.setTitre(rs.getString(2));
                a.setCategorie(rs.getString(3));
                a.setSousTitre(rs.getString(4));
                a.setChapeau(rs.getString(5));
                a.setTexte(rs.getString(6));
                a.setNbLikes(rs.getInt(7));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return a;
      }  
     
    public void incrementNbLikes(int IdA){
         String requete="UPDATE article SET nbLikes=nbLikes+1  WHERE IdA="+IdA;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("like added");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
 
    public void likerArticle(int idA,int idU) throws SQLException{
        if(!verifLike(idA,idU)){
        String requete = "INSERT into likes(idArticle,idUser)values ('"+idA+"','"+idU+"')";
        try{
        Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("like ajouté");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        incrementNbLikes(idA);
        }else{
            System.out.println("Vous likez deja l'article");
        }
    }
    public boolean verifLike(int idA,int idU) throws SQLException{
        String requete = "select * from likes WHERE idArticle="+idA+" AND idUser="+idU;
        int idLike=0;
        try{
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()){
                idLike=rs.getInt(1);
              
            }
        }catch (SQLException ex){
        Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(idLike == 0){
            return false;}
        else {return true;  } 
        }    
     public int CountX(ObservableList<Article> articleList){
        return articleList.size();
    }
    }
   

   

  


