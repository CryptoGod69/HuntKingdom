/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Models.PeriodeChasse;
import Utils.DataSource;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Legion
 */
public class PeriodeChasseService {
    Connection cnx = DataSource.getInstance().getCnx();
    
    public void ajouterPeriodeChasse(PeriodeChasse p) throws SQLException{
        Date dateDebut = java.sql.Date.valueOf(p.getDateDebut());
        Date dateFin = java.sql.Date.valueOf(p.getDateFin());
        String requete = "insert into periodechasse (dateDebut,dateFin,adresse,superficie) values ('"+dateDebut+"','"+dateFin+"','"+p.getAdresse()+"','"+p.getSuperficie()+"')";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("zone de chasse ajoutée avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /*
    public void ajouterZoneChasse2(ZoneChasse z) throws SQLException {
        String requete = "insert into zonechasse (dateDebut,dateFin,adresse,superficie) values ('"+z.getDateDebut()+"','"+z.getDateFin()+"','"+z.getAdresse()+"','"+z.getSuperficie()+"')";
        try {
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1,z.getDateDebut());
            pst.setString(2,z.getDateFin());
            pst.setString(3,z.getAdresse());
            pst.setInt(4, z.getSuperficie());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
   public ObservableList<PeriodeChasse> getListPeriodeChasse(){
        ObservableList<PeriodeChasse> periodeChasseList = FXCollections.observableArrayList();
        String requete = "select * from periodechasse";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                PeriodeChasse z = new PeriodeChasse();
                z.setIdP(rs.getInt(1));
                z.setDateDebut(rs.getDate(2).toLocalDate());
                z.setDateFin(rs.getDate(3).toLocalDate());
                z.setAdresse(rs.getString(4));
              z.setSuperficie(rs.getInt(5));
                periodeChasseList.add(z);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return periodeChasseList;
    }
   public ObservableList<PeriodeChasse> rechercherPeriodeChasseAdresse(String adresse){
        ObservableList<PeriodeChasse> periodeChasseList = FXCollections.observableArrayList();
        String requete = "select * from periodechasse WHERE adresse="+(char)34+adresse+(char)34;
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                PeriodeChasse z = new PeriodeChasse();
                z.setIdP(rs.getInt(1));
                z.setDateDebut(rs.getDate(2).toLocalDate());
                z.setDateFin(rs.getDate(3).toLocalDate());
                z.setAdresse(rs.getString(4));
              z.setSuperficie(rs.getInt(5));
                periodeChasseList.add(z);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return periodeChasseList;
    }
    public void supprimerPeriodeChasse(int IdP) throws SQLException {
       String requete = "DELETE FROM periodechasse WHERE IdP="+IdP;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Période de chasse supprimée");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
      public void modifierPeriodeChasse (int IdP,LocalDate dateDebut,LocalDate dateFin,String adresse,int superficie){
             String requete="UPDATE periodechasse SET dateDebut='"+java.sql.Date.valueOf(dateDebut)+"',dateFin='"+java.sql.Date.valueOf(dateFin)+"',adresse='"+adresse+"',superficie='"+superficie+"' WHERE IdP="+IdP;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("periode de chasse bien modifiée");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
      public PeriodeChasse rechercherPeriodeChasse(int IdP){
          PeriodeChasse p = new PeriodeChasse();
        String requete = "select * from periodechasse WHERE IdP="+IdP;
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            
            while(rs.next()) {
                p.setIdP(rs.getInt(1));
                p.setDateDebut(rs.getDate(2).toLocalDate());
                p.setDateFin(rs.getDate(3).toLocalDate());
                p.setAdresse(rs.getString(4));
                p.setSuperficie(rs.getInt(5));
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
      }   
}
