package jfxtras.labs.scene.control.edittable;

/**
 * Contains a list of table property types.  They match the TableView columns. 
 * 
 * @author David Bal
 *
 * @param <S>
 */
public class TableProperty<S>
{
	// TODO
}
