package jfxtras.labs.internal.scene.control.skin.edittable;

import javafx.collections.ObservableList;
import jfxtras.labs.scene.control.edittable.TableProperty;

public interface EditTableSkin
{
	public ObservableList<TableProperty> getTableList();
}
