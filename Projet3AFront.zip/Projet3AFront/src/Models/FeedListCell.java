/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
/**
 *
 * @author mouradsmac
 */
public class FeedListCell extends ListCell<Feed> {
    private final GridPane gridPane = new GridPane(); 
    
    private final Label idClientLabel= new Label();
    private final Label titreLabel= new Label(); 
    private final Label contLabel= new Label(); 


    private final ImageView feedIcon = new ImageView(); 
    private final AnchorPane content = new AnchorPane(); 
    
    public FeedListCell() { 
        feedIcon.setFitWidth(20); 
        feedIcon.setPreserveRatio(true); 
        GridPane.setConstraints(feedIcon, 0, 0, 1, 3); 
        GridPane.setValignment(feedIcon, VPos.TOP); 
        // 
        titreLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(titreLabel, 0, 1); 
        // 
        idClientLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(idClientLabel, 0, 2); 
        //
        contLabel.setStyle("-fx-opacity: 0.75;"); 
        GridPane.setConstraints(contLabel, 2 , 0 ); 
        
        
        //                 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getColumnConstraints().add(new ColumnConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, HPos.LEFT, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.NEVER, VPos.CENTER, true)); 
        gridPane.getRowConstraints().add(new RowConstraints(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE, Priority.ALWAYS, VPos.CENTER, true)); 
        gridPane.setHgap(6); 
        gridPane.setVgap(6); 
        gridPane.getChildren().setAll(feedIcon, titreLabel, idClientLabel,contLabel); 
        AnchorPane.setTopAnchor(gridPane, 0d); 
        AnchorPane.setLeftAnchor(gridPane, 0d); 
        AnchorPane.setBottomAnchor(gridPane, 0d); 
        AnchorPane.setRightAnchor(gridPane, 0d); 
        content.getChildren().add(gridPane);
    }
    
    @Override 
    protected void updateItem(Feed feed, boolean empty) { 
        super.updateItem(feed, empty); 
        setGraphic(null); 
        setText(null); 
        setContentDisplay(ContentDisplay.LEFT); 
        if (!empty && feed != null) { 
            
            titreLabel.setText(feed.getTitrePub());
            contLabel.setText("Orga :"+ feed.getContPub() );
            idClientLabel.setText("Lieu :"+feed.getidClient() ); 
 
            String path = "";
            path = "/Resources/feed/"+feed.getIdPub()+".jpg";
            Image image = new Image(getClass().getResource(path).toExternalForm());
            if(image != null){
                feedIcon.setImage(image);
            }
            setText(null);
            setGraphic(content); 
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
    
}
