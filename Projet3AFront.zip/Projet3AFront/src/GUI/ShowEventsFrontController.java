/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.ShowEventsController.user;
import Models.Evenement;
import Models.EvenementListCell;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowEventsFrontController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button joinButton;
    @FXML
    private ListView<Evenement> EventList;
    @FXML
    private Button returnButton;
    @FXML
    private Button feedButton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // TODO
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowEventsFrontController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
     private void Load() throws SQLException {
        for(int i=0; i<EventList.getItems().size(); i++){
            EventList.getItems().clear();
        }
        EvenementService es = new EvenementService();
        ObservableList<Evenement> elist = es.showEventList();
        EventList.setItems(elist);
          
        EventList.setCellFactory(new Callback<ListView<Evenement>, ListCell<Evenement>>() { 
            @Override 
            public ListCell<Evenement> call(ListView<Evenement> lv) { 
                return new EvenementListCell(); 
            } 
        });      
    }
    @FXML
    private void Add(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader(getClass().getResource("AddEventFront.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
    }
    @FXML
    private void joinEvent(ActionEvent event) throws SQLException, IOException {
        if(EventList.getSelectionModel().getSelectedItem() != null){
            EvenementService es = new EvenementService();
            Evenement e = EventList.getSelectionModel().getSelectedItem();
            es.Participer(e.getIdEvent(), user.getIdUser());
            Load();
    }
    }
    @FXML
    private void Return(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEventsFront.fxml"));
        VBox root = new VBox();
        root.getChildren().add(loader.load());
        EventList.getScene().setRoot(root);
    }
    @FXML
    private void goFeed(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowFeedPubFront.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
    }
    
}
