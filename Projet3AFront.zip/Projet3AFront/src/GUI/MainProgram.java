/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.User;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author mouradsmac
 */
public class MainProgram extends Application {
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        User user = new User(753,"mourad","tlili","1 rue de la paix","mourad.tlili@esprit.tn","71123123","Admin", new Date(01,01,1998).toLocalDate());
        ShowEventsController.user = user;
        Parent root = FXMLLoader.load(getClass().getResource("ShowEventsFront.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Feed Table");
        primaryStage.setScene(scene);
        primaryStage.show();
        /*
        Parent root = FXMLLoader.load(getClass().getResource("ShowEvents.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Event");
        primaryStage.setScene(scene);
        primaryStage.show();
        */

        }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
