/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.ResourceBundle;
import static java.util.concurrent.TimeUnit.DAYS;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class AddEventController implements Initializable {

    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;
    @FXML
    private TextField orgaField;
    @FXML
    private TextField descField;
    @FXML
    private TextField titleField;
    @FXML
    private TextField lieuField;
    private TextField typeField;
    @FXML
    private TextField partsField;
   /*
    @FXML
    private TextField dateField;
   */
    @FXML 
    private ComboBox typeComboBox;
    @FXML
    private DatePicker dateField;
    
    ObservableList<String> typeList = FXCollections.observableArrayList("Chasse","Formation","Reunion");
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       typeComboBox.setValue("Chasse");
       typeComboBox.setItems(typeList);
    }    

    @FXML
    private void cancel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        orgaField.getScene().setRoot(root);
        
    }
    @FXML
    private void save(ActionEvent event) throws IOException, SQLException {
        /*if (!titleField.getText().isEmpty() && !dateField.getText().isEmpty() && !lieuField.getText().isEmpty() && typeField.getText().isEmpty()) 
        {
        */
          EvenementService es = new EvenementService();
         
          Evenement e = new Evenement(titleField.getText() , orgaField.getText() ,lieuField.getText() ,descField.getText() ,typeComboBox.getValue().toString() ,Integer.parseInt(partsField.getText()),dateField.getValue());
            es.addEvent(e);
            System.out.println("OK");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
            Parent root = loader.load();
            orgaField.getScene().setRoot(root);
            ShowEventsController spc = loader.getController();
        }   
}
//}
