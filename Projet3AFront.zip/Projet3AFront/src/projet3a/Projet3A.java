/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet3a;

import Models.Evenement;
import Models.Feed;
import Services.EvenementService;
import Services.FeedService;
import Utils.DataSource;
import Services.PersonneService;
import java.sql.Date;
import static java.sql.JDBCType.NULL;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 *
 * @author Mourad
 */
public class Projet3A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        DataSource ds = DataSource.getInstance();
        System.out.println(ds.hashCode());
    
        Evenement e = new Evenement("Test ","Marmar Tlili","Tunis","Blabla ","Formation",233,new Date(20,02,2020).toLocalDate());
        EvenementService es = new EvenementService();
        es.addEvent(e);//Ajouter Un Evenement
        es.removeEvent(7);    //Supprimer un Evenement
        System.out.println(es.showOneEvent(7));//Afficher un Evenement
        System.out.println(es.showEventList());//Afficher liste de toutes les Evenements
        es.updateEvent(7,"HunntttShiiit","Mourad Tliliii","Ariana","aaa","Chasse",123,new Date(20,02,2020).toLocalDate()); //Modifier un Evenement
        System.out.println(e.getTitre()+"--> ADDED TO EVENT LIST");//Msg de validation
      
    /*
        Feed f = new Feed(10,"this is only a test","This is MEEE");//Creation d un Publication
        FeedService fs = new FeedService();//Creation D'instance FeedService
        fs.addPub(f); //Ajouter Publication
        fs.removePub(1); //Supprimer Publication
        System.out.println(fs.showOnePub(2)); //Afficher une Publication
        System.out.println(fs.showPubList());  //Afficher plusieurs Publications
        fs.updatePub(4,99,"TRAKTRAK", "BLABLABLA");
   */
  
    }
  
}
