/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Mourad
 */
public class Feed {
    
    private int idPub;
    private int idClient;
    private String TitrePub;    
    private String ContPub;

    public Feed() {
     this.idClient = 0;
     this.TitrePub = "";
     this.ContPub = "";
    }

    public Feed(int idClient, String TitrePub, String ContPub) {
        this.idClient = idClient;
        this.TitrePub = TitrePub;
        this.ContPub = ContPub;
    }


    public int getIdPub() {
        return idPub;
    }

    public String getTitrePub() {
        return TitrePub;
    }

    public int getidClient() {
        return idClient;
    }

    public String getContPub() {
        return ContPub;
    }

    public void setIdPub(int idPub) {
        this.idPub = idPub;
    }

    public void setTitrePub(String TitrePub) {
        this.TitrePub = TitrePub;
    }

    public void setidClient(String DescPub) {
        this.idClient = idClient;
    }

    public void setContPub(String ContPub) {
        this.ContPub = ContPub;
    }

    @Override
    public String toString() {
        return "Feed{" + "idPub=" + idPub + ", idClient=" + idClient + ", TitrePub=" + TitrePub + ", ContPub=" + ContPub + '}';
    }
    
 
     
}