/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Models.Evenement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Utils.DataSource;
import java.sql.JDBCType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Mourad
 */
public class EvenementService {
    
    Connection cnx = DataSource.getInstance().getCnx(); 
    public void addEvent(Evenement E) throws SQLException{
       
        int insEvent=E.getIdEvent();
        String insTitre=E.getTitre();
        String insOrganisateur=E.getOrganisateur();
        String insLieu=E.getLieu();
        String insDescription=E.getDescription();
        String insType=E.getType();
        int insNbrPart=E.getNbrPart();
        String insDate=E.getDate();
        String requete = "INSERT into Evenement(idEvent,Titre,Organisateur,Lieu,Description,Type,NbrPart,Date)values ('"+insEvent+"','"+insTitre+"' ,'"+insOrganisateur+"' , '"+insLieu+"' , '"+insDescription+"' , '"+insType+"' , '"+insNbrPart+"' , '"+insDate+"'  )";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Ajout effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       public void removeEvent(int id) 
       {
                   
        String requete = "DELETE FROM Evenement WHERE idEvent="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Suppression effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       public Evenement showOneEvent(int id) throws SQLException{
       
          Evenement E = new Evenement();  
        String requete = "SELECT * FROM Evenement WHERE idEvent="+id;    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      E.setIdEvent(rs.getInt(1));
                      E.setTitre(rs.getString(2));
                      E.setOrganisateur(rs.getString(3));
                      E.setLieu(rs.getString(4));
                      E.setDescription(rs.getString(5));
                      E.setType(rs.getString(6));
                      E.setNbrPart(rs.getInt(7));
                      E.setDate(rs.getString(8));                    
          }               
           
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return E;
    }
     
    public ObservableList<Evenement> showEventList() throws SQLException{
       
          ObservableList<Evenement> ListEvent =  FXCollections.observableArrayList();  
        String requete = "SELECT * FROM Evenement";    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      Evenement E = new Evenement();
                      E.setIdEvent(rs.getInt(1));
                      E.setTitre(rs.getString(2));
                      E.setOrganisateur(rs.getString(3));
                      E.setLieu(rs.getString(4));
                      E.setDescription(rs.getString(5));
                      E.setType(rs.getString(6));
                      E.setNbrPart(rs.getInt(7));
                      E.setDate(rs.getString(8));   
                      ListEvent.add(E);                      
          }                        
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return ListEvent;
    }
    public void updateEvent (int idd,String Titre,String Organisateur,String Lieu,String Description,String Type,int nbrPart,String Date)
     {
             String requete="UPDATE Evenement SET Titre='"+Titre+"',Organisateur='"+Organisateur+"',Lieu='"+Lieu+"',Description='"+Description+"',Type='"+Type+"',nbrPart='"+nbrPart+"',Date='"+Date+"' WHERE idEvent="+idd;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Evenement bien Modifié");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    }

