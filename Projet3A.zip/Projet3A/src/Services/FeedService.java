/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Models.Evenement;
import Models.Feed;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Utils.DataSource;
import java.sql.JDBCType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Mourad
 */
public class FeedService {
    
    Connection cnx = DataSource.getInstance().getCnx(); 
    public void addPub(Feed F) throws SQLException{
       
        int insidPub=F.getIdPub();
        int insidClient=F.getidClient();
        String insTitre=F.getTitrePub();      
        String insCont=F.getContPub();
        
        String requete = "INSERT into Feed(idPub,idClient,TitrePub,ContPub)values ('"+insidPub+"','"+insidClient+"','"+insTitre+"','"+insCont+"')";
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Ajout Publication effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       public void removePub(int id) throws SQLException{
                   
        String requete = "DELETE FROM Feed WHERE idPub="+id;
        try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Suppression effectué");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       
       public Feed showOnePub(int id) throws SQLException{
       
          Feed F = new Feed();  
        String requete = "SELECT * FROM Feed WHERE idPub="+id;    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      F.setIdPub(rs.getInt(1));
                      F.setidClient(rs.getString(2));
                      F.setTitrePub(rs.getString(3));
                      F.setContPub(rs.getString(4));                                       
          }               
           
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return F;
    }
     
    public ObservableList<Feed> showPubList() throws SQLException{
       
          ObservableList<Feed> ListPub = FXCollections.observableArrayList();  
        String requete = "SELECT * FROM Feed";    
        try{
           Statement st = cnx.createStatement();
           ResultSet rs=st.executeQuery(requete);
           while(rs.next()){
                      Feed F = new Feed();
                      F.setIdPub(rs.getInt(1));
                      F.setidClient(rs.getString(2));
                      F.setTitrePub(rs.getString(3));
                      F.setContPub(rs.getString(4));
                         
                      ListPub.add(F);                      
          }                        
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);          
        }
        return ListPub;
    }
   /*
    public void ajouterPersonne2(Evenement E) throws SQLException {
        String requete = "INSERT into Evenement (idEvent,Titre,Organisateur,Lieu,Description,Type,nbrPart,Date) values " + " ('"+E.getIdEvent()+"' , '"+E.getTitre()+"' , '"+E.getOrganisateur()+"', '"+E.getLieu()+"' , '"+E.getDescription()+"' , '"+E.getType()+"' , '"+E.getNbrPart()+"' , '"+E.getDate()+"' , ')";
        try {
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1,E.getIdEvent());
            pst.setString(2, E.getTitre());
            pst.setString(3, E.getOrganisateur());
            pst.setString(4, E.getLieu());
            pst.setString(5, E.getDescription());
            pst.setString(6, E.getType());
            pst.setInt(7, E.getNbrPart());
            pst.setString(8, E.getDate());
            
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   */
    
    /*
    public List<Evenement> getListPersonne(){
        List<Evenement> list = new ArrayList<>();
        String requete = "SELECT * from Evenement";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while(rs.next()) {
                Evenement  = new Evenement();
                p.getIdEvent(rs.getInt(1));
                p.setNom(rs.getString(2));
                p.setPrenom(rs.getString("prenom"));
                list.add(p);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
        * **/
   
   public void updatePub (int idd,int idC,String Titre,String Cont)
     {
             String requete="UPDATE Feed SET idClient='"+idC+"',TitrePub='"+Titre+"',ContPub='"+Cont+"' WHERE idPub="+idd;
         try{
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("Publication bien Modifié ;) ");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
     }

  

    }

