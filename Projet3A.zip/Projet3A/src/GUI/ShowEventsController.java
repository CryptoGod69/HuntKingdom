/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowEventsController implements Initializable {

    @FXML
    private Button showButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private TableView<Evenement> EventList;
    @FXML
    private TableColumn<Evenement, String> idColumn;
    @FXML
    private TableColumn<Evenement, String> TitleColumn;
    @FXML
    private TableColumn<Evenement, String> OrgaColumn;
    @FXML
    private TableColumn<Evenement, String> LieuColumn;
    @FXML
    private TableColumn<Evenement, String> DescColumn;
    @FXML
    private TableColumn<Evenement, String> TypeColumn;
    @FXML
    private TableColumn<Evenement, String> PartsColumn;
    @FXML
    private TableColumn<Evenement, String> DateColumn;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowEventsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }     

    @FXML
    private void Show(ActionEvent event) {
        
    }
    
       private void Load() throws SQLException {
        EvenementService es = new EvenementService();
        ObservableList<Evenement> elist = es.showEventList();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idEvent"));
        TitleColumn.setCellValueFactory(new PropertyValueFactory<>("Titre"));
        OrgaColumn.setCellValueFactory(new PropertyValueFactory<>("Organisateur"));
        LieuColumn.setCellValueFactory(new PropertyValueFactory<>("Lieu"));
        DescColumn.setCellValueFactory(new PropertyValueFactory<>("Description"));
        TypeColumn.setCellValueFactory(new PropertyValueFactory<>("Type"));
        PartsColumn.setCellValueFactory(new PropertyValueFactory<>("nbrPart"));
        DateColumn.setCellValueFactory(new PropertyValueFactory<>("Date"));

        EventList.setItems(elist);
    }

    @FXML
    private void Add(ActionEvent event) throws IOException {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("AddEvent.fxml"));
        Parent root = loader.load();
        EventList.getScene().setRoot(root);
    }

    @FXML
  
    private void Edit(ActionEvent event) throws IOException {  
        EvenementService es = new EvenementService();
        Evenement e = EventList.getSelectionModel().getSelectedItem();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditEvent.fxml"));
        Parent root = loader.load();        
        EventList.getScene().setRoot(root);
        EditEventController etc = loader.getController();
       etc.idField.setText(Integer.toString(e.getIdEvent()));
        etc.titleField.setText(e.getTitre());
        etc.orgaField.setText(e.getOrganisateur());
        etc.lieuField.setText(e.getLieu());
        etc.descField.setText(e.getDescription());
        etc.typeField.setText(e.getType());
       etc.partsField.setText(Integer.toString(e.getNbrPart()));
        etc.dateField.setText(e.getDate());       
    }
    @FXML

    private void Delete(ActionEvent event) throws SQLException { 
        EvenementService es = new EvenementService();
        Evenement e = EventList.getSelectionModel().getSelectedItem();
        es.removeEvent(e.getIdEvent());
        Load();
        
    }
    
}
