/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Models.Feed;
import Services.EvenementService;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class ShowFeedPubController implements Initializable {

    @FXML
    private TableView<Feed> tablePub;
    @FXML
    private TableColumn<Feed, String> idPub;
    
    @FXML
    private TableColumn<Feed, String> userPub;
    @FXML
    private TableColumn<Feed, String> titrePub;
    @FXML
    private TableColumn<Feed, String> contPub;
    @FXML
    private Button showButton;
    @FXML
    private Button addButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Load();
        } catch (SQLException ex) {
            Logger.getLogger(ShowFeedPubController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void show(ActionEvent event) {
    }
 private void Load() throws SQLException {
        FeedService fs = new FeedService();
        ObservableList<Feed> flist = fs.showPubList();
        idPub.setCellValueFactory(new PropertyValueFactory<>("idPub"));
        userPub.setCellValueFactory(new PropertyValueFactory<>("idClient"));
        titrePub.setCellValueFactory(new PropertyValueFactory<>("TitrePub"));
        contPub.setCellValueFactory(new PropertyValueFactory<>("ContPub"));
      
       // DateColumn.setCellValueFactory(new PropertyValueFactory<>("Date"));

        tablePub.setItems(flist);
    }
    @FXML
    private void add(ActionEvent event) throws IOException {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("AddFeedPub.fxml"));
        Parent root = loader.load();
        tablePub.getScene().setRoot(root);
    }

    @FXML
    private void edit(ActionEvent event) throws IOException {
        
        FeedService fs = new FeedService();
        Feed f = tablePub.getSelectionModel().getSelectedItem();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditFeedPub.fxml"));
        Parent root = loader.load();        
        tablePub.getScene().setRoot(root);
        EditFeedPubController efpc = loader.getController();
        efpc.idField.setText(Integer.toString(f.getIdPub() ));
        efpc.userField .setText(Integer.toString(f.getidClient() ));
        efpc.titreField.setText(f.getTitrePub());
        efpc.contField.setText(f.getContPub());
    }

    @FXML
    private void delete(ActionEvent event) throws SQLException {
        FeedService fs = new FeedService();
        Feed f = tablePub.getSelectionModel().getSelectedItem();
        fs.removePub(f.getIdPub());
        Load();
    
}
}
