/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Feed;
import Services.FeedService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class AddFeedPubController implements Initializable {

    @FXML
    private TextField idField;
    @FXML
    private TextField userField;
    @FXML
    private TextField titreField;
    @FXML
    private TextField contField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void cancel(ActionEvent event) {
    }

    @FXML
    private void save(ActionEvent event) throws IOException, SQLException {
            FeedService fs = new FeedService();
          Feed f = new Feed(Integer.parseInt(userField.getText()),titreField.getText() ,contField.getText());
            fs.addPub(f);
            System.out.println("OK");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
            Parent root = loader.load();
            idField.getScene().setRoot(root);
            ShowEventsController spc = loader.getController();
        }
    
    }
    

