/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Models.Evenement;
import Services.EvenementService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author mouradsmac
 */
public class EditEventController implements Initializable {

    @FXML
    protected TextField idField;
    @FXML
    protected TextField dateField;
    @FXML
    protected TextField lieuField;
    @FXML
    protected TextField titleField;
    @FXML
    protected TextField orgaField;
    @FXML
    protected TextField partsField;
    @FXML
    protected TextField descField;
    @FXML
    protected TextField typeField;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void cancel(ActionEvent event) {
    }

    @FXML
    private void save(ActionEvent event) throws IOException {
        EvenementService es = new EvenementService();
        es.updateEvent(Integer.parseInt(idField.getText()) , titleField.getText() , orgaField.getText() ,lieuField.getText() ,descField.getText() ,typeField.getText() ,Integer.parseInt(partsField.getText()) ,dateField.getText());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowEvents.fxml"));
        Parent root = loader.load();
        idField.getScene().setRoot(root);                  
    }

    public void setIdField(TextField idField) {
        this.idField = idField;
    }

    public void setDateField(TextField dateField) {
        this.dateField = dateField;
    }

    public void setLieuField(TextField lieuField) {
        this.lieuField = lieuField;
    }

    public void setTitleField(TextField titleField) {
        this.titleField = titleField;
    }

    public void setOrgaField(TextField orgaField) {
        this.orgaField = orgaField;
    }

    public void setPartsField(TextField partsField) {
        this.partsField = partsField;
    }

    public void setDescField(TextField descField) {
        this.descField = descField;
    }

    public void setTypeField(TextField typeField) {
        this.typeField = typeField;
    }

    public void setCancelButton(Button cancelButton) {
        this.cancelButton = cancelButton;
    }

    public void setSaveButton(Button saveButton) {
        this.saveButton = saveButton;
    }
    

}

